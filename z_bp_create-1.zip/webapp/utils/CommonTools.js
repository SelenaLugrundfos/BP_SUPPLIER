//# sourceURL=PictureUploader.js
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/base/Object",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function(jQuery, BaseObject, MessageToast, JSONModel, MessageBox) {
	"use strict";

	var CommonTools = BaseObject.extend("grundfos.Z_BP_CREATE.CommonTools", {
		constructor: function(component) {
			this._component = component;
		}
	});
	
	//Check for non-latin characters
	CommonTools.prototype.hasNonLatinCharacters = function(text2Check) {
          var containNotLatin = false;
          text2Check = text2Check.toLowerCase();
          
        //handle overrides (Fill in here)
        var overrideChars = [
          	"å","æ","ø","à","á","â","ä","ã","ā","ą","ă","ǎ","ç","ĉ","č","ć","Ch","ð","ď","ǆ","è","é","ê","ë","ę","ē",
          	"ĕ","ė","ě","ĝ","ğ","ġ","ģ","ǧ","ĥ","ħ","ì","í","î","ï","į","ı","ĩ","ī","ĭ","ĵ","ķ","ǩ","ĺ","ļ","ľ","ŀ",
          	"ł","ń","ņ","ñ","ň","ò","ó","ô","ö","õ","ő","ǫ","ō","ŏ","ơ","ŕ","ŗ","ř","ś","ŝ","ş","ș","š","ß","ŧ",
          	"ţ","ț","þ","ù","ú","û","ü","ũ","ū","ŭ","ų","ů","ű","ƿ","ȝ","ư","ŵ","ý","ŷ","ÿ","ź","ž","ż"];
        for( var i = 0; i< overrideChars.length; i++ ) {
        	var regExp = new RegExp( overrideChars[i], 'g' );
        	text2Check = text2Check.replace(regExp,"");
        }
          
        for(var i=0;i<text2Check.length;i++) {
          		
          	  var char = text2Check.charCodeAt(i);
          	 
          	  if( char > 127 ) {
          	  	containNotLatin = true;
          	  	break;
          	  }
         }
         
         return containNotLatin;
    };

	//Show busy indicator
	CommonTools.prototype.showBusy = function(duration, delay) {

		//Set delay on when to show the dialogue
		sap.ui.core.BusyIndicator.show(delay);

		//If duration is specified make delayed call
		if (duration && duration > 0) {

			//Clear any ongoing calls
			if (this._sTimeoutId) {
				jQuery.sap.clearDelayedCall(this._sTimeoutId);
				this._sTimeoutId = null;
			}

			this._sTimeoutId = jQuery.sap.delayedCall(duration, this, function() {
				this.hideBusy();
			});
		}
	};

	//hide busy indicator
	CommonTools.prototype.hideBusy = function(duration) {

		if (duration && duration > 0) {

			//Clear any ongoing calls
			if (this._sTimeoutId) {
				jQuery.sap.clearDelayedCall(this._sTimeoutId);
				this._sTimeoutId = null;
			}
			
			//Setupp timeout
			this._sTimeoutId = jQuery.sap.delayedCall(duration, this, function() {
				sap.ui.core.BusyIndicator.hide();
			});
		} else {
			sap.ui.core.BusyIndicator.hide();
		}

	};

	//Show a messagebox with a given i18n text and messageType
	CommonTools.prototype.showMessage = function(messageI18n, type, title) {
		var that = this;
		return new Promise(function(resolve, reject) {
			if( !title )
			{
				title = "";
			}
			var message = that.getText(messageI18n);

			MessageBox[type](
				message, {
					styleClass: "sapUiSizeCompact",
					onClose: resolve,
					title: title
				}
			);
		});
	};
	
	//Show a messagebox with a given i18n text and messageType
	CommonTools.prototype.showMessageFromString = function(message, type, title) {
		return new Promise(function(resolve) {
			
			if( !title )
			{
				title = "";
			}
			
			MessageBox[type](
				message, {
					styleClass: "sapUiSizeCompact",
					onClose: resolve,
					title: title
				}
			);
		});
	};

	//Show a message toast
	CommonTools.prototype.showToast = function(message, duration) {
		sap.m.MessageToast.show(message, {
			duration: (duration) ? duration : 3000, // default
			width: "15em", // default
			my: "center bottom", // default
			at: "center bottom", // default
			of: window, // default
			offset: "0 0", // default
			collision: "fit fit", // default
			onClose: null, // default
			autoClose: true, // default
			animationTimingFunction: "ease", // default
			animationDuration: 1000, // default
			closeOnBrowserNavigation: true // default
		});
	};

	//Get i18n Text
	CommonTools.prototype.getText = function(i18nText) {
		return this._component.getModel("i18n").getResourceBundle().getText(i18nText);
	};

	return CommonTools;

});