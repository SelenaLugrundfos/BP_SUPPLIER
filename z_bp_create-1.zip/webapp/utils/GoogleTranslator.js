//# sourceURL=PictureUploader.js
sap.ui.define([
	"jquery.sap.global",
	"sap/ui/base/Object"
], function(jQuery, BaseObject) {
	"use strict";

	var GoogleTranslator = BaseObject.extend("grundfos.Z_BP_CREATE.CommonTools", {
		constructor: function(component) {
			
			sap.ui.require("http://www.google.com/jsapi");
			
			this._component = component;
		}
	});

	return GoogleTranslator;

});