sap.ui.define([
	"grundfos/Z_BP_CREATE/test/unit/controller/Main.controller"
], function () {
	"use strict";
});