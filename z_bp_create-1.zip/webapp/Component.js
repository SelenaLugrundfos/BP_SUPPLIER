sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"grundfos/Z_BP_CREATE/model/models",
	"grundfos/Z_BP_CREATE/utils/CommonTools",
	"grundfos/Z_BP_CREATE/utils/GoogleTranslator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (UIComponent, Device, models, CommonTools, GoogleTranslator, JSONModel, MessageToast, MessageBox) {
	"use strict";

	return UIComponent.extend("grundfos.Z_BP_CREATE.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {

			//API KEYS
			// this._googleKey = "AIzaSyADA2M_23Ms41hsW9Rv_r1EUoOnCu9gPZE";
			this._googleKey = "AIzaSyDtWji9bqeGjfI-MtFcVdHGpMrcy-T6Z8I";

			//We need tools
			this._tools = new CommonTools(this);

			//Model events
			this.modelInit();

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			//Initialize google api
			this.initGoogle();

			//Get Initial F4s
			this.preloadF4s();

			//Set initial ViewProperties
			this.setViewProperties();

		},

		showMessagesFromError: function (error, title) {
			var oResourceBundle = this.getModel("i18n").getResourceBundle();
			var sMessage = oResourceBundle.getText("ErrorMessage");
			var message = "";
			if (error) {
				var json = $.parseJSON(error.responseText);
				var field = null;
				if (json.error && json.error.innererror && json.error.innererror.errordetails) {
					for (var i = 0; i < json.error.innererror.errordetails.length; i++) {
						var errTmp = json.error.innererror.errordetails[i];
						message += errTmp.message;
						message += "\n";

						if (field === null && errTmp.target && errTmp.target.trim().length > 0) {
							field = errTmp.target;
						}
					}
				}
				if (message === "") {
					//	message = json.error.message.value;  //Actual ErrorMessage - Only for Developers
					message = sMessage;
				}
				this.getTools().showMessageFromString(message, "error", title);

			}
		},

		openExternalHelp: function () {
			if (!document.getElementById("helpLink")) {
				var link = document.createElement("a");
				link.id = 'helpLink';
				link.target = "_blank";
				link.href = this.getModel("AppControl").getProperty("/externalHelp");
				document.body.appendChild(link);
			}
			document.getElementById('helpLink').click();
		},

		setAppModelValue: function (prop, value) {
			this.getModel("App").setProperty("/" + prop, value);
		},

		formHasNonLatinCharacters: function () {
			var hasNonLatin = false;

			var checkFields = [
				"Name1",
				"Name2",
				"HouseNum",
				"Searchterm",
				"Street",
				"City1",
				"City2"
			];

			for (var i = 0; i < checkFields.length; i++) {
				var valTmp = this.getFieldValue("SearchFormSupplier", checkFields[i]);
				if (this.getTools().hasNonLatinCharacters(valTmp)) {
					hasNonLatin = true;
					break;
				}
			}

			return hasNonLatin;
		},

		checkFieldsStep1: function () {
			var mandtFields = [
				"Name1",
				"Searchterm",
				"Country",
				"City1"
			];

			//Non latin characters in the form?
			var hasLatin = this.formHasNonLatinCharacters();
			this.getModel("UIControl").setProperty("/InternationalAddressFields/visible", hasLatin);
			if (hasLatin) {
				mandtFields.push("Name1I");
				mandtFields.push("SearchTermI");
				mandtFields.push("StreetI");
				mandtFields.push("City1I");

				if (!this._hasShowLatinMessage) {
					sap.m.MessageBox.information(this.getTools().getText("HelpText-NonLatinCharacters"), {
						styleClass: "sapUiSizeCompact",
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: this.getTools().getText("Title-InfoMessage")
					});
					this._hasShowLatinMessage = true;
				}
			}

			//Add Region??
			if (this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Region/required") === true) {
				mandtFields.push("Region");
			}
			if (this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/PostCode1/required") === true) {
				mandtFields.push("PostCode1");
			}
			if (this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Street/required") === true) {
				mandtFields.push("Street");
			}

			var valid = true;
			var that = this;
			
			for (var i = 0; i < mandtFields.length; i++) {

				var valTmp = this.getFieldValue("SearchFormSupplier", mandtFields[i]);

				if (this.isEmpty(valTmp) === true) {
					valid = false;
				}
				if (mandtFields[i] === "PostCode1"){
					var oPostCodeValueState = that.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/PostCode1/valueState");
					if (oPostCodeValueState === sap.ui.core.ValueState.Error ){
						valid = false;
					}
				}
			}

			//Reduce characters from search reults if they exceed 40.
			var oName1Value = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Name1/value");
			if (oName1Value.length > 40) {
				oName1Value = oName1Value.slice(0, 40);
				this.setFieldValue("SearchFormSupplier", "Name1", oName1Value);
			}

			//Sets properties on Footer Buttons
			this.showAllFooterButtons(false);
			this.setFooterButtonProps("SupplierStep", {
				enabled: valid,
				visible: true
			});
			this.setFooterButtonProps("CustomerStep", {
				enabled: valid,
				visible: true
			});
		},
		validatePostCode1: function () {
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			var region = this.getFieldValue("SearchFormSupplier", "Region");
			var postCode = this.getFieldValue("SearchFormSupplier", "PostCode1");
			return this.callFunction("ValidatePostCode", {
				Region: region,
				Country: country,
				PostCode: postCode
			});
		},

		setCompCodeDefaults: function (oEvent) {
			var dataPack = this.getCompCodeData(oEvent.getSource().getSelectedKey());
			this._setCompCodeDefaultsInternal(dataPack);
		},

		_setCompCodeDefaultsInternal: function (dataPack) {
			this.setFieldValue("SearchFormSupplier", "PaymtMethod", dataPack.PaymtMethod);
			this.setFieldValue("SearchFormSupplier", "PaymtKey", dataPack.PaymtKey);
			this.setFieldValue("SearchFormSupplier", "Inco1", dataPack.Inco1);

			// start of insert by EDM 18/06/2018
			/*			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/FileName1/visible", dataPack.ShowAttach);
						this.getModel("UIControl").setProperty("/UploadBut/visible", dataPack.ShowAttach);*/
			// end of insert by EDM 18/06/2018
		},

		checkFieldsStep2: function () {
			//this._wizard.discardProgress(this._wizard.getSteps()[1]);
			var mandtFields = [
				"CompCode",
				"PurchOrg"
			];

			var valid = true;

			for (var i = 0; i < mandtFields.length; i++) {
				var valTmp = this.getFieldValue("SearchFormSupplier", mandtFields[i]);

				if (this.isEmpty(valTmp) === true) {
					valid = false;
				}
			}
			this.showAllFooterButtons(false);
			this.getModel("UIControl").setProperty("/SupplierSearch/enabled", valid);
		},

		checkCustFieldsStep2: function () {
			//this._wizard.discardProgress(this._wizard.getSteps()[1]);
			this.clearCustSearchResults();

			var mandtFields = [
				"CompCode",
				"SalesOrg",
				"AccountGroup",
				"DistChannel",
				"Division",
				"Langu"
				//  "TimeZone"
				//	"TransportZone"

			];

			var valid = true;
			var vatRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormCustomer/VatRegNo/required");

			if (vatRequired) {
				mandtFields.push("VatRegNo");
			}

			//TransportZone - Added JRA 18.06.2020
			var tzoneRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormCustomer/TransportZone/required");
			if (tzoneRequired) {
				mandtFields.push("TransportZone");
			}

			//TimeZone - Added JRA 10.08.2020
			var timezoneRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormCustomer/TimeZone/required");
			if (timezoneRequired) {
				mandtFields.push("TimeZone");
			}
		
			for (var i = 0; i < mandtFields.length; i++) {
				var valTmp = this.getFieldValue("SearchFormCustomer", mandtFields[i]);
                
				if (this.isEmpty(valTmp) === true) {
					valid = false;
				}
			}
			
			//SalesOffice - Added Rock 02.1.2021
		 	var SalesOfficeRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormCustomer/SalesOffice/required");
	      	if (SalesOfficeRequired) {
	 	     var salesoffice = this.getFieldValue("SearchFormCustomer", "SalesOffice");
	 	     if( salesoffice === undefined ){
	 	        valid = false;
	 	     }
	 	     else{
	 	      if (this.isEmpty(salesoffice) === true) {
					valid = false;
				}
	 	     }
		    }
		    
		 	//SalesGroup - Added Rock 02.1.2021
	    	var SalesGroupRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormCustomer/SalesGroup/required");
		   	if (SalesGroupRequired) {
		 	  var salesgroup = this.getFieldValue("SearchFormCustomer", "SalesGroup");
		 	  if( salesgroup === undefined ){
		 	  	 valid = false;
		 	   }
	 	     else{
	 	      if (this.isEmpty(salesgroup) === true) {
					valid = false;
			   }
	 	     }
	      	}


			
			
			this.showAllFooterButtons(false);
			/*	
				if (valid === true){
					this.fieldsvalid = true;
					
				} else {
					this.fieldsvalid = false;
				}
			//	this.getModel("UIControl").setProperty("/FooterButtons/SubmitCustomer/enabled", valid);


				var searchMandtFields = [
					"CompCode",
					"SalesOrg",
					"AccountGroup"
				];

				var searchValid = true;

				for (var j = 0; j < searchMandtFields.length; j++) {
					var searchValTmp = this.getFieldValue("SearchFormCustomer", searchMandtFields[j]);

					if (this.isEmpty(searchValTmp) === true) {
						searchValid = false;
					}
				}*/
			if (this._vatRegValid === true && this.VatEUValid === true) {
				this.getModel("UIControl").setProperty("/CustomerSearch/enabled", valid);
			} else if (valid === false) {
				this.getModel("UIControl").setProperty("/CustomerSearch/enabled", valid);
			} else if (valid === true) {
				this.getModel("UIControl").setProperty("/CustomerSearch/enabled", valid);
			} else {
				this.getModel("UIControl").setProperty("/CustomerSearch/enabled", false);
			}
		},

		clearCustSearchResults: function () {
			//	var oTable = sap.ui.getCore("CustomerTable");

			this.setModel(models.createModel([]), "CustomerList");
			this.enableCustSubmitButton(false);

		},

		enableCustSubmitButton: function (valid) {

			this.getModel("UIControl").setProperty("/FooterButtons/SubmitCustomer/enabled", valid);

		},

		checkFieldsStep3: function () {
			//this._wizard.discardProgress(this._wizard.getSteps()[2]);
			var mandtFields = [
				"Langu"
			];
			var emailRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Email/required");
			if (emailRequired) {
				mandtFields.push("Email");
			}
			var TelNoRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/TelNo/required");
			if (TelNoRequired) {
				mandtFields.push("TelNo");
			}
			var valid = true;

			for (var i = 0; i < mandtFields.length; i++) {
				var valTmp = this.getFieldValue("SearchFormSupplier", mandtFields[i]);

				if (this.isEmpty(valTmp) === true) {
					valid = false;
				}
			}

			this.showAllFooterButtons(false);
			this.setFooterButtonProps("NextStep", {
				enabled: valid,
				visible: true
			});
		},

		setStep4Specifics: function () {
			var mode = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/IbanMode/mode");
			var iban = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Iban/value");
			var bankCountry = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/BankCnt/value");
			var bankKey = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/BankKey/value");
			var bankAccount = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/BankAcc/value");
			var oSupplierNeedExtensionValue = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/value");

			if (oSupplierNeedExtensionValue) {
				if ((!iban) && (!bankCountry) && (!bankKey) && (!bankAccount)) {
					this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/mode", "IBAN");
					mode = "IBAN";
				} else {
					if (!iban) {
						if ((bankCountry) && (bankKey) && (bankAccount)) {
							this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/mode", "NOIBAN");
							this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/enabled", false);
							mode = "NOIBAN";
						}
					} else {
						this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/mode", "IBAN");
						mode = "IBAN";
					}
				}
			} else {
				if (!mode) {
					this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/mode", "IBAN");
					mode = "IBAN";
				}
			}
			var textKey = (mode !== "GIRO") ? "Label-BankAcc" : "Label-GiroNum";
			this.getModel("AppControl").setProperty("/BankKeyText", this.getTools().getText(textKey));
		},

		checkFieldsStep4: function () {
			//this._wizard.discardProgress(this._wizard.getSteps()[3]);
			var mandtFields = [
				"PaymtKey",
				"BankCnt",
				"BankKey",
				"BankAcc"
			];

			var PaymtMethodRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/PaymtMethod/required");
			if (PaymtMethodRequired) {
				mandtFields.push("PaymtMethod");
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PaymtMethod/enabled", true);
			} else {
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PaymtMethod/enabled", false);
			}

			var valid = true;

			// start of insert by EDM 31/05/2018
			var bankRequired = this.isBankRequired();
			var fileName1Name = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/FileName1/name");
			var fileName1Required = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/FileName1/required");
			var oSupplierNeedExtensionValue = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/value");
			if (oSupplierNeedExtensionValue) {
				bankRequired = false;
			}
			if (bankRequired) {
				// end of insert by EDM 31/05/2018	

				for (var i = 0; i < mandtFields.length; i++) {
					var valTmp = this.getFieldValue("SearchFormSupplier", mandtFields[i]);

					if (this.isEmpty(valTmp) === true) {
						valid = false;
					}
				}

			} //insert by EDM 31/05/2018

			var ibanRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Iban/required");
			var iban = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Iban/value");

			if (ibanRequired === true) {
				if (iban) {
					valid = true;
				} else {
					valid = false;
				}
			}
			if (fileName1Required === true) {
				if (fileName1Name === false) {
					valid = false;
				}
			}
			this.showAllFooterButtons(false);
			this.setFooterButtonProps("NextStep", {
				enabled: valid,
				visible: true
			});
		},

		compileSubmitData: function () {
			var dataUnparsed = this.getModel("ApplicationFields").getData().Sections.SearchFormSupplier;
			var newdataobj = {};
			var oSupplierNeedExtensionValue = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/click");
			//	dataUnparsed.Name2plus1.remove();
			//Set the std properties
			for (var property in dataUnparsed) {
				if (dataUnparsed.hasOwnProperty(property)) {
					if (property === "Name1") {
						if (oSupplierNeedExtensionValue) {
							if (dataUnparsed[property].value) {
								newdataobj[property] = dataUnparsed[property].value;
							} else {
								var oBussinessPartnerText = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/BusinessPartner/text");
								newdataobj[property] = oBussinessPartnerText;
							}
						} else {
							newdataobj[property] = dataUnparsed[property].value;
						}
					} else {
						newdataobj[property] = dataUnparsed[property].value;
					}
				}
			}

			//Add the attachments
			var attachments = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/Attachments");
			for (var i = 0; i < attachments.length; i++) {
				var attTmp = attachments[i];
				newdataobj["FileName" + attTmp.fileindex] = this.getFileName(attTmp.filename);
				newdataobj["FileType" + attTmp.fileindex] = this.getFileExtension(attTmp.filename);
				newdataobj["FileContent" + attTmp.fileindex] = btoa(attTmp.fileobj);
			}

			return newdataobj;
		},

		submitSupplier: function (view) {
			var that = this;
			return new Promise(function (resolve, reject) {
				var data = that.compileSubmitData();

				that.getModel().create("/VendorSet", data, {
					success: resolve,
					error: reject
				});
			});

		},

		compileSubmitCustData: function () {
			var dataUnparsedCustomer = this.getModel("ApplicationFields").getData().Sections.SearchFormCustomer;
			var dataUnparsedSupplier = this.getModel("ApplicationFields").getData().Sections.SearchFormSupplier;
			var dataUnparsed = JSON.parse(JSON.stringify(dataUnparsedCustomer));
			dataUnparsed.Country = dataUnparsedSupplier.Country;
			dataUnparsed.City1 = dataUnparsedSupplier.City1;
			dataUnparsed.City2 = dataUnparsedSupplier.City2;
			dataUnparsed.HouseNum = dataUnparsedSupplier.HouseNum;
			dataUnparsed.Name1 = dataUnparsedSupplier.Name1;
			dataUnparsed.Name2 = dataUnparsedSupplier.Name2;
			dataUnparsed.PostCode1 = dataUnparsedSupplier.PostCode1;
			dataUnparsed.Street = dataUnparsedSupplier.Street;
			dataUnparsed.Region = dataUnparsedSupplier.Region;
			dataUnparsed.PostBox = dataUnparsedSupplier.PostBox;
			dataUnparsed.PostCode2 = dataUnparsedSupplier.PostCode2;
			dataUnparsed.Searchterm = dataUnparsedSupplier.Searchterm;
			dataUnparsed.Langu = dataUnparsedCustomer.Langu;
			//Non-Latin Fields
			dataUnparsed.Name1I = dataUnparsedSupplier.Name1I;
			dataUnparsed.Name2I = dataUnparsedSupplier.Name2I;
			dataUnparsed.StreetI = dataUnparsedSupplier.StreetI;
			dataUnparsed.HouseNumI = dataUnparsedSupplier.HouseNumI;
			dataUnparsed.City1I = dataUnparsedSupplier.City1I;
			dataUnparsed.City2I = dataUnparsedSupplier.City2I;
			dataUnparsed.SearchTermI = dataUnparsedSupplier.SearchTermI;
			dataUnparsed.CustomerNo = {
				value: "01"
			};

			var newdataobj = {};
			//Set the std properties
			for (var property in dataUnparsed) {
				if (dataUnparsed.hasOwnProperty(property)) {
					newdataobj[property] = dataUnparsed[property].value;
				}
			}

			//Add the attachments
			var attachments = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/Attachments");
			for (var i = 0; i < attachments.length; i++) {
				var attTmp = attachments[i];
				newdataobj["FileName" + attTmp.fileindex] = this.getFileName(attTmp.filename);
				newdataobj["FileType" + attTmp.fileindex] = this.getFileExtension(attTmp.filename);
				newdataobj["FileContent" + attTmp.fileindex] = btoa(attTmp.fileobj);
			}

			return newdataobj;
		},

		submitCustomer: function (view) {
			var that = this;

			//	return new Promise(function (resolve, reject) {
			var data = that.compileSubmitCustData();

			that.getModel().create("/CustomerSet", data, {
				success: this.submitCustomerSuccess.bind(this),
				error: this.submitCustomerError.bind(this)
			});
			//	});

		},

		submitCustomerSuccess: function (response) {
			var that = this;
			MessageBox.success(
				response.Message, {
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function () {
						window.top.location.reload();
					}
				});
		},

		submitCustomerError: function (error) {
			var that = this;
			var title = that.getTools().getText("Submit Data Failed");
			that.showMessagesFromError(error, title);
		},

		checkFieldsStep5: function () {
			var mandtFields = [
				"VendType"
			];
			var oSupplierNeedExtensionValue = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/value");

			if (!oSupplierNeedExtensionValue) {
				//If Vat is required add to checklist
				var vatRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/VatRegNo/required");
				if (vatRequired) {
					mandtFields.push("VatRegNo");
				}
			}

			var Inco1Required = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Inco1/required");
			var CurrencyRequired = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/Currency/required");

			if (Inco1Required) {
				mandtFields.push("Inco1");
			}

			if (CurrencyRequired) {
				mandtFields.push("Currency");
			}

			var valid = true;

			for (var i = 0; i < mandtFields.length; i++) {
				var valTmp = this.getFieldValue("SearchFormSupplier", mandtFields[i]);
				if (mandtFields[i] === "VendType" && (this.isEmpty(valTmp) === true)) {
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendType/value", "I");
					valTmp = this.getFieldValue("SearchFormSupplier", mandtFields[i]);
				}
				if (this.isEmpty(valTmp) === true) {
					valid = false;
				}
			}

			if (valid && vatRequired) {
				//DoubleCheck if vatreg has been validated ok
				valid = this._vatRegValid;
			}

			//Should we check attachment signature?
			var signatureCheck = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/AttachmentSignatureRequired");
			var attachments = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/Attachments");
			if (valid && signatureCheck) {
				valid = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/AttachmentSignatureSigned");

				//Checked but nothing uploaded?
				if (valid && attachments.length === 0) {
					valid = false;
				}
			}

			//Should we check TypeOfBusiness?
			var checkTOB = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/TypeOfBusiness/visible");
			if (valid && checkTOB) {
				valid = (!this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/TypeOfBusiness/value") || this.getModel(
					"ApplicationFields").getProperty("/Sections/SearchFormSupplier/TypeOfBusiness/value") === "") ? false : true;
			}

			this.showAllFooterButtons(false);
			this.setFooterButtonProps("Submit", {
				enabled: valid,
				visible: true
			});
		},

		isEmpty: function (value) {
			return (value === null || value.length === 0);
		},

		getTools: function () {
			return this._tools;
		},

		modelInit: function () {
			var that = this;

			//Show busy while fetching the metadata
			this.getTools().showBusy(0, 0);
			this.getModel().attachMetadataLoaded(null, function () {
				that.getTools().hideBusy(1000);
			}, null);

			//Hook up and send wait dialog when requests are sent
			this.getModel().attachRequestSent(null, function () {
				that.getTools().showBusy(0, 0);
			}, null);

			//Thigs we do when request is success
			this.getModel().attachRequestCompleted(null, function () {
				that.getTools().hideBusy(800);
			}, null);

			//Thigs we do when request is failed
			this.getModel().attachRequestFailed(null, function () {
				that.getTools().hideBusy(800);
			}, null);

			//Metadata failed event
			this.getModel().attachMetadataFailed(null, function () {
				that.getTools().hideBusy(0);
				that.getTools().showMessage("Message-ConnectionProblems", "error");
				that.applicationLoadFailed();
			}, null);
		},

		checkVatRegNoFromEU: function (vatReg) {
			var that = this;
			that.VatEUValid = false;

			that.VatEUValid = true; // Delete after inserting commented code again.

			/*	var country = vatReg.substring(0, 2);
				var vatRegNumber = vatReg.slice(2);
				var request = '<?xml version="1.0" encoding="UTF-8"?>' +

					'<x:Envelope xmlns:x="http://schemas.xmlsoap.org/soap/envelope/" ' +

					'xmlns:urn="urn:ec.europa.eu:taxud:vies:services:checkVat:types">' +

					"<x:Header/>" +

					"<x:Body>" +

					"<urn:checkVat>" +

					"<urn:countryCode>" + country + "</urn:countryCode>" +

					"<urn:vatNumber>" + vatRegNumber + "</urn:vatNumber>" +

					"</urn:checkVat>" +

					"</x:Body>" +

					"</x:Envelope>";

				var url = "/VatRegNoVIES";

				var aData = jQuery.ajax({

					url: url,

					type: "POST",

					dataType: "text",

					data: request,

					contentType: "text/xml; charset=\"utf-8\"",

					success: function (data, textStatus, jqXHR) {

						if (data.indexOf(true) > -1) {
							MessageToast.show("Valid Vat Number");
							that.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
								.Success);
							that.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueStateTxt", that.getTools().getText(
								"Message-VatRegValid"));
							that.VatEUValid = true;
							that.checkCustFieldsStep2();
						} else if (data.indexOf(false) > -1) {
							MessageToast.show("Vat Number Does Not Exist");
							that.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
								.Error);
							that.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueStateTxt", that.getTools().getText(
								"Message-VatRegInvalid"));
							that.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueStateTxt", that.getTools().getText(
								"Message-VatRegInvalid"));
							that.getModel("UIControl").setProperty("/CustomerSearch/enabled", false);
							that.VatEUValid = false;
							that.checkCustFieldsStep2();

						} else {
							that.getModel("UIControl").setProperty("/CustomerSearch/enabled", false);
							MessageToast.show("Could not validate Vat Number. VIES Service might be down. Try again later");
						}
					},

					error: function ()

					{

						MessageToast.show("Something went wrong");

					}

				});*/

		},

        checkSOSGenable1:function(accountgrp){
          	var that = this;
			var salesorg = that.getFieldValue("SearchFormCustomer", "SalesOrg");
        	return this.callFunction("ValidateSoffSgrpEnable", {
				SalesOrg: salesorg,
				AccountGrp: accountgrp
			});
        },
        
        checkSOSGenable2:function(salesorg){
          	var that = this;
			var accountgrp = that.getFieldValue("SearchFormCustomer", "AccountGroup");
        	return this.callFunction("ValidateSoffSgrpEnable", {
				SalesOrg: salesorg,
				AccountGrp: accountgrp
			});
        },

		checkVatRegInSAP: function () {
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			var vatReg = this.getFieldValue("SearchFormSupplier", "VatRegNo");
			return this.callFunction("ValidateVatRegNo", {
				Country: country,
				VatRegNo: vatReg
			});
		},

		checkCustVatRegInSAP: function () {
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			var vatReg = this.getFieldValue("SearchFormCustomer", "VatRegNo");
			return this.callFunction("ValidateVatRegNo", {
				Country: country,
				VatRegNo: vatReg
			});

		},
		checkCustTaxNoInSAP: function (oTaxField) {
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			var region = this.getFieldValue("SearchFormSupplier", "Region");
			var taxno1 = this.getFieldValue("SearchFormCustomer", "TaxNo1");
			var taxno2 = this.getFieldValue("SearchFormCustomer", "TaxNo2");
			var taxno3 = this.getFieldValue("SearchFormCustomer", "TaxNo3");
			var taxno4 = this.getFieldValue("SearchFormCustomer", "TaxNo4");
			switch (oTaxField) {
			case "TaxNo1":
				taxno2 = "";
				taxno3 = "";
				taxno4 = "";
				break;
			case "TaxNo2":
				taxno1 = "";
				taxno3 = "";
				taxno4 = "";
				break;
			case "TaxNo3":
				taxno1 = "";
				taxno2 = "";
				taxno4 = "";
				break;
			case "TaxNo4":
				taxno1 = "";
				taxno2 = "";
				taxno3 = "";
				break;
			default:
			}
			return this.callFunction("ValidateTaxNum", {
				Country: country,
				Region: region,
				TaxNum1: taxno1,
				TaxNum2: taxno2,
				TaxNum3: taxno3,
				TaxNum4: taxno4
			});
		},

		checkSupplierTaxNoInSAP: function (oTaxField) {
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			var region = this.getFieldValue("SearchFormSupplier", "Region");
			var taxno1 = this.getFieldValue("SearchFormSupplier", "TaxNo1");
			var taxno2 = this.getFieldValue("SearchFormSupplier", "TaxNo2");
			var taxno3 = this.getFieldValue("SearchFormSupplier", "TaxNo3");
			var taxno4 = this.getFieldValue("SearchFormSupplier", "TaxNo4");
			switch (oTaxField) {
			case "TaxNo1":
				taxno2 = "";
				taxno3 = "";
				taxno4 = "";
				break;
			case "TaxNo2":
				taxno1 = "";
				taxno3 = "";
				taxno4 = "";
				break;
			case "TaxNo3":
				taxno1 = "";
				taxno2 = "";
				taxno4 = "";
				break;
			case "TaxNo4":
				taxno1 = "";
				taxno2 = "";
				taxno3 = "";
				break;
			default:
			}
			return this.callFunction("ValidateTaxNum", {
				Country: country,
				Region: region,
				TaxNum1: taxno1,
				TaxNum2: taxno2,
				TaxNum3: taxno3,
				TaxNum4: taxno4
			});
		},

		applicationLoadFailed: function () {
			this._appLoadFailed = true;
			this.getModel("UIControl").setProperty("/Wizard/visible", false);
		},

		showAllFooterButtons: function (show) {
			var props = {
				visible: show
			};
			this.showHideSupplierButtons(show);
			this.setFooterButtonProps("PrevStep", props);
			//	this.setFooterButtonProps("NextStep", props);
			this.setFooterButtonProps("Submit", props);
			this.setFooterButtonProps("SupplierStep", props);
			this.setFooterButtonProps("CustomerStep", props);
			//	this.setFooterButtonProps("SubmitCustomer", props);
			//	this.setFooterButtonProps("CancelCustomer", props);
			this.setFooterButtonProps("CustomerPrevStep", props);
		},

		showHideSupplierButtons: function (show) {
			var props = {
				visible: show
			};

			var oBusinessPartnerDisplay = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/BusinessPartner/display");
			this.setFooterButtonProps("SupplierFound", props);
			if (!oBusinessPartnerDisplay) {
				this.setFooterButtonProps("SupplierNotFound", props);
			}
			this.setFooterButtonProps("SupplierFoundOutside", props);
		},

		setFooterButtonProps: function (name, propsObj) {
			Object.keys(propsObj).forEach(function (key, index) {
				//this.getModel("UIControl").setProperty("/FooterButtons/" + name + "/" + key, );
			});

			for (var property in propsObj) {
				if (propsObj.hasOwnProperty(property)) {

					var value = propsObj[property];
					this.getModel("UIControl").setProperty("/FooterButtons/" + name + "/" + property, value);
				}
			}

		},

		preloadF4s: function () {
			var that = this;

			//Country
			this.callFunction("GetCountryList", {}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4Countries");
				});

		},

		refreshBankvisibility: function (clear) {
			var bankRequired = this.isBankRequired();
			this.setStep4Specifics();
			var mode = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/IbanMode/mode");
			var oSupplierNeedExtensionValue = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/value");

			//defaults
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/enabled", true);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/enabled", true);

			if (mode === "GIRO") {

				//Bank Key
				this.setFieldValue("SearchFormSupplier", "BankKey", "0001");
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/enabled", false);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/required", false);
				//Disable Bank Control Key
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/enabled", false);
				//Enable Bank Country
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/enabled", true);
				//Disable Iban
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/required", false);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/enabled", false);
				//Enable Bank Account
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/required", true);

				//sap.ui.getCore().byId("inputBankAccount").focus();

			} else {
				//If NOIBAN then clear some fields
				if (mode === "NOIBAN" && clear) {
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/value", "");
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/value", "");
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/value", "");
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/value", "");
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/value", "");
				}

				if (oSupplierNeedExtensionValue === false) {
					this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/enabled", true);
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/required", (bankRequired && mode === "IBAN"));
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/enabled", (bankRequired && mode === "IBAN"));

					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/enabled", (bankRequired && mode === "NOIBAN"));
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/required", (bankRequired && mode ===
						"NOIBAN"));

					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/enabled", (bankRequired && mode === "NOIBAN"));
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/required", (bankRequired && mode ===
						"NOIBAN"));

					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/enabled", (bankRequired && mode === "NOIBAN"));
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/required", (bankRequired && mode ===
						"NOIBAN"));

					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/enabled", (bankRequired && mode ===
						"NOIBAN"));

				} else {
					this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/required", false);
					this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/enabled", false);

					if (mode === "NOIBAN" || mode === "IBAN") {
						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/enabled", false);
						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/required", false);

						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/enabled", false);
						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/required", false);

						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/enabled", false);
						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/required", false);

						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/enabled", false);

						this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/enabled", false);
					}
				}

			}

		},

		isBankRequired: function () {
			var payterm = this.getFieldValue("SearchFormSupplier", "PaymtMethod");
			var required = false;
			var oSupplierNeedExtensionValue = this.getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/value");

			if (this.getModel("F4PayMethods")) {
				var payterms = this.getModel("F4PayMethods").getData();
				for (var i = 0; i < payterms.length; i++) {
					if (payterms[i].PayMethodKey === payterm) {
						required = payterms[i].BankReq;
						break;
					}
				}
			}

			if (oSupplierNeedExtensionValue) {
				required = false;
			}

			return required;
		},

		loadStep4: function () {
			var that = this;

			//Show next button
			this.setFooterButtonProps("NextStep", {
				enabled: false,
				visible: true
			});

			//Payment Methods
			var params = {
				CompCode: this.getFieldValue("SearchFormSupplier", "CompCode")
			};

			this.callFunction("GetPayMethodList", params).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4PayMethods");

					//Check if bank is required
					that.refreshBankvisibility();
				});

			//Payment terms
			if (!this.getModel("F4PayTerms")) {
				this.callFunction("GetPayTermList", {}).then(
					function (data) {
						that.setModel(models.createModel(data.results), "F4PayTerms");
					});
			}

			//this._wizard.nextStep();
			this.getModel("AppControl").setProperty("/visibleStep", 4);
			this.checkFieldsStep4();
		},

		loadStep5: function () {
			var that = this;
			//Show Submit button
			this.setFooterButtonProps("Submit", {
				enabled: false,
				visible: true
			});
			this.setFooterButtonProps("NextStep", {
				enabled: false,
				visible: false
			});

			//IncoList
			if (!this.getModel("F4Inco")) {
				this.callFunction("GetIncoList", {}).then(
					function (data) {

						for (var i = 0; i < data.results.length; i++) {
							data.results[i].Inco1txt = data.results[i].Inco1Key + " - " + data.results[i].Inco1txt;
						}

						//We have a default value?
						var inco1 = that.getFieldValue("SearchFormSupplier", "Inco1");
						if (inco1) {
							for (var j = 0; j < data.results.length; j++) {
								if (inco1 === data.results[j].Inco1Key) {
									that.setFieldValue("SearchFormSupplier", "Inco2", ((data.results[j].Inco2Default) ? data.results[j].Inco2Default : ""));
									break;
								}
							}
						}

						that.setModel(models.createModel(data.results), "F4Inco");
					});
			}

			//Currency
			if (!this.getModel("F4Currency")) {
				this.callFunction("GetCurrencyList", {}).then(
					function (data) {

						for (var i = 0; i < data.results.length; i++) {
							data.results[i].CurrencyText = data.results[i].CurrencyKey + " - " + data.results[i].CurrencyText;
						}

						that.setModel(models.createModel(data.results), "F4Currency");
					});
			}

			//this._wizard.nextStep();
			this.getModel("AppControl").setProperty("/visibleStep", 5);
			this.checkFieldsStep5();
		},

		_checkBankFieldsInternal: function (countryData) {
			//Show/hide fields basedpayment fields based on iban true/false
			if (countryData) {
				/*	this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/visible", countryData.Iban);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/visible", countryData.Iban);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/visible", countryData.Iban);
*/
				this._ibanCheck = countryData.Iban;

				//Set required for vatRegNo
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/required", countryData.VatRegNo);

			} else {
				this._ibanCheck = false;
			}
		},

		checkBankFields: function (oEvent) {
			if (oEvent) {
				var country = this.getFieldValue("SearchFormSupplier", "BankCnt");
				var countryData = this.getCountryData(country);

				this._checkBankFieldsInternal(countryData);
			}
		},

		checkIBANOnline: function (iban) {
			var that = this;
			return new Promise(function (resolve, reject) {
				if (that.getModel("AppControl").getProperty("/services/iban/enabled") === true) {
					var params = "format=json&" +
						"api_key=" + that.getModel("AppControl").getProperty("/services/iban/key") +
						"&iban=" + iban;
					var url = that.getModel("AppControl").getProperty("/services/iban/url") + "?" + params;

					//Call the service
					$.ajax({
						dataType: "json",
						crossDomain: true,
						url: url,
						success: resolve,
						error: reject
					});
				} else {
					reject("IBAN online service not enabled - could not verify it");
				}
			});

		},

		setBankDataFromIban: function (data) {
			if (!data) {
				return;
			}

			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/value", data.BankCnt);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/value", data.BankKey);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/value", data.BankAcc);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/value", data.Bank_c_key);
		},

		checkIBANSAP: function (iban) {
			var that = this;
			var params = {
				Iban: iban
			};
			return that.callFunction("ValidateIBAN", params);
		},

		checkBankSAP: function () {
			var that = this;
			var bankKey = this.getFieldValue("SearchFormSupplier", "BankKey");
			var bankCnt = this.getFieldValue("SearchFormSupplier", "BankCnt");
			var bankContKey = this.getFieldValue("SearchFormSupplier", "BankContKey");
			var bankAcc = this.getFieldValue("SearchFormSupplier", "BankAcc");

			var params = {
				BankKey: bankKey,
				BankCnt: bankCnt,
				BankContKey: bankContKey,
				BankAcc: bankAcc
				
			};
			return that.callFunction("ValidateBank", params);
		},

		loadStep3: function () {
			//Show next button
			this.setFooterButtonProps("NextStep", {
				enabled: false,
				visible: true
			});

			var that = this;
			//Languages
			this.callFunction("GetLanguageList", {}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4Languages");
				});
			//this._wizard.nextStep();
			this.getModel("AppControl").setProperty("/visibleStep", 3);
			this.checkFieldsStep3();
		},
		checkCompCodeValue: function (oEvent) {
			var Enabled = true;
			if (oEvent.getSource().getSelectedKey() === "") {
				Enabled = false;
			} else {
				Enabled = true;
			}
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/AccountGroup/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TelNo/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/FaxNo/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/Email/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo1/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo2/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo3/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo4/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOrg/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/DistChannel/enabled", Enabled);
			//	this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/Division/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/Langu/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TimeZone/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/enabled", Enabled);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", true);
		},

		loadCustomerStep2: function () {
			this.ClearCustStep2Fields();
			//Show next button
			this.setFooterButtonProps("SupplierStep", {
				enabled: false,
				visible: false
			});
			this.setFooterButtonProps("CustomerStep", {
				enabled: false,
				visible: false
			});
			this.setFooterButtonProps("SubmitCustomer", {
				enabled: false,
				visible: true
			});
			this.setFooterButtonProps("CancelCustomer", {
				enabled: true,
				visible: true
			});
			this.getModel("UIControl").setProperty("/UploadBut/visible", true);
			this.getModel("AppControl").setProperty("/visibleStep", 6);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState.None);

			var that = this;

			//CompanyCode

			if (!this.getModel("F4CompCode")) {
				this.callFunction("GetCustCompCodeList", {}).then(
					function (data) {
						that.setModel(models.createModel(data.results), "F4CompCode");
						var oDefaultBool = false;
						if (data.results && data.results.length === 1) {
							that.setFieldValue("SearchFormCustomer", "CompCode", data.results[0].CompCodeKey);
							that._setCustCompCodeDefaultsInternal(data.results[0]);
							that.loadSalesOrg(data.results[0].CompCodeKey);
							that.loadCustTimeZone(data.results[0].CompCodeKey);
							that.loadCustTransportZone(data.results[0].CompCodeKey);
							that.defaultCompCode = "" + data.results[0].CompCodeKey + "";
						} else {
							//Check for default
							for (var i = 0; i < data.results.length; i++) {
								if (data.results[i].Default === true) {
									that.setFieldValue("SearchFormCustomer", "CompCode", data.results[i].CompCodeKey);
									that._setCustCompCodeDefaultsInternal(data.results[i]);
									that.loadSalesOrg(data.results[i].CompCodeKey);
									that.loadCustTimeZone(data.results[i].CompCodeKey);
									that.loadCustTransportZone(data.results[i].CompCodeKey);
									oDefaultBool = true;
									that.defaultCompCode = "" + data.results[i].CompCodeKey + "";
									break;
								}
							}
							if (oDefaultBool === false) {
								that.setFieldValue("SearchFormCustomer", "CompCode", data.results[0].CompCodeKey);
								that.loadSalesOrg(data.results[0].CompCodeKey);
								that.loadCustTimeZone(data.results[0].CompCodeKey);
								that.loadCustTransportZone(data.results[0].CompCodeKey);
								that.defaultCompCode = "" + data.results[0].CompCodeKey + "";
							}

						}

					});
			} else {
				that.setFieldValue("SearchFormCustomer", "CompCode", that.defaultCompCode);
				that.loadSalesOrg(that.defaultCompCode);
				that.loadCustTransportZone(that.defaultCompCode);
			}
			this.loadCustLangu();
			this.checkCustFieldsStep2();
		},
		loadDistChannel: function (salesorg) {
			var that = this;
			//Languages
			this.callFunction("GetDistChannelList", {
				SalesOrg: salesorg
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "DistChannel");
					var oDefaultBool = false;
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "DistChannel", data.results[0].DistChan);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "DistChannel", data.results[i].DistChan);
								oDefaultBool = true;
								break;
							}
						}
						if (oDefaultBool === false) {
							that.setFieldValue("SearchFormCustomer", "DistChannel", data.results[0].DistChan);
						}
					}

				});
		},

		loadSalesOrg: function (compCode) {
			var that = this;
			this.CompCode = compCode;
			this.salesOrg = "";

			this.callFunction("GetSalesOrgList", {
				CompCode: compCode
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4SalesOrg");
					var oDefaultBool = false;
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "SalesOrg", data.results[0].vkorg);
						that.loadAccountGroup(compCode, data.results[0].vkorg);
						that.loadDistChannel(data.results[0].vkorg);
						that.loadSalesOffice(data.results[0].vkorg);
						that.salesOrg = data.results[0].vkorg;
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "SalesOrg", data.results[i].vkorg);
								that.loadAccountGroup(compCode, data.results[i].vkorg);
								that.loadDistChannel(data.results[i].vkorg);
								that.loadSalesOffice(data.results[i].vkorg);
								oDefaultBool = true;
								that.salesOrg = data.results[i].vkorg;
								break;
							}
						}
						if (oDefaultBool === false) {
							that.setFieldValue("SearchFormCustomer", "SalesOrg", data.results[0].vkorg);
							that.loadAccountGroup(compCode, data.results[0].vkorg);
							that.loadDistChannel(data.results[0].vkorg);
							that.loadSalesOffice(data.results[0].vkorg);
							that.salesOrg = data.results[0].vkorg;
						}
					}

				});

			this.checkCustFieldsStep2();
		},
		
		loadSalesOffice: function (salesOrgCode) {
			var that = this;
			var DC = that.getFieldValue("SearchFormCustomer", "DistChannel");
			this.callFunction("GetSalesOfficeList", {
				SalesOrg: salesOrgCode,
				DistChan: DC,
				Division: "01"
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4SalesOffice");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "SalesOffice", data.results[0].SalesOffice);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "SalesOffice", data.results[i].SalesOffice);
								break;
							}
						}
					}
				});
		},
		
		reLoadSalesOffice: function () {
			var that = this;
			var salesOrgCode = that.getFieldValue("SearchFormCustomer", "SalesOrg");
			var DC = that.getFieldValue("SearchFormCustomer", "DistChannel");
			this.callFunction("GetSalesOfficeList", {
				SalesOrg: salesOrgCode,
				DistChan: DC,
				Division: "01"
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4SalesOffice");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "SalesOffice", data.results[0].SalesOffice);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "SalesOffice", data.results[i].SalesOffice);
								break;
							}
						}
					}
				});
		},
		
		reLoadSalesGroup: function () {
			var that = this;
			var SalesOffice = that.getFieldValue("SearchFormCustomer", "SalesOffice");
			this.callFunction("GetSalesGroupList", {
				SalesOffice: SalesOffice
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4SalesGroup");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "SalesGroup", data.results[0].SalesGroup);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "SalesGroup", data.results[i].SalesGroup);
								break;
							}
						}
					}
				});
		},
		
		loadSalesGroup: function (SalesOffice) {
			var that = this;
			this.callFunction("GetSalesGroupList", {
				SalesOffice: SalesOffice
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4SalesGroup");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "SalesGroup", data.results[0].SalesGroup);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "SalesGroup", data.results[i].SalesGroup);
								break;
							}
						}
					}
				});
		},

		loadAccountGroup: function (compCode, salesOrgCode) {
			var that = this;
			this.callFunction("GetAccountGrpList", {
				SalesOrg: salesOrgCode,
				CompCode: compCode
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4CustAccountGroup");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "AccountGroup", data.results[0].AccountGroup);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "AccountGroup", data.results[i].AccountGroup);
								break;
							}
						}
					}
				});
		},

		updateAccountGroup: function (salesOrg) {

			this.loadAccountGroup(this.CompCode, salesOrg);
		},
		updateSalesOffice: function (salesOrg) {

			this.loadSalesOffice(salesOrg);
		},
		
		updateSalesGroup: function (salesOffice) {

			this.loadSalesGroup(salesOffice);
			if (salesOffice === ""){this.setFieldValue("SearchFormCustomer", "SalesGroup", "");}
		},
		
		
		setCustCompCodeDefaults: function (oEvent) {
			var dataPack = this.getCustCompCodeData(oEvent.getSource().getSelectedKey());
			this._setCustCompCodeDefaultsInternal(dataPack);
		},
		getCustCompCodeData: function (cc) {
			var ccList = this.getModel("F4CompCode").getData();
			var returnData = null;
			for (var i = 0; i < ccList.length; i++) {
				if (ccList[i].CompCodeKey === cc) {
					returnData = ccList[i];
					break;
				}
			}

			return returnData;
		},

		_setCustCompCodeDefaultsInternal: function (dataPack) {
			/*	this.setFieldValue("SearchFormCustomer", "PaymtMethod", dataPack.PaymtMethod);
				this.setFieldValue("SearchFormCustomer", "PaymtKey", dataPack.PaymtKey);
				this.setFieldValue("SearchFormCustomer", "Inco1", dataPack.Inco1);*/
		},

		onCustomerPrevStep: function () {
			var currentStep = this.getModel("AppControl").getProperty("/visibleStep") - 5;
			this.getModel("AppControl").setProperty("/visibleStep", (currentStep));

			this.handleFooterButtons((currentStep));

		},

		loadCustLangu: function () {
			var that = this;
			//Languages
			this.callFunction("GetLanguageList", {}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4CustLanguages");
				});

		},

		loadCustTimeZone: function (compCode) {
			var that = this;
			//Languages
			this.callFunction("GetTimeZoneList", {
				CompCode: compCode
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4CustTimezone");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "TimeZone", data.results[0].TimeZoneKey);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "TimeZone", data.results[i].TimeZoneKey);

								break;
							}
						}

					}
				});
		},

		loadCustTransportZone: function (compCode) {
			var that = this;
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			//Languages
			this.callFunction("GetTransportZoneList", {
				CompCode: compCode,
				Country: country
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4CustTransportZone");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormCustomer", "TransportZone", data.results[0].TransportZoneKey);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormCustomer", "TransportZone", data.results[i].TransportZoneKey);

								break;
							}
						}

					}
				});
		},

		loadPurchacingOrg: function (compCode) {
			var that = this;
			//PurchOrg
			this.callFunction("GetPurchOrgList", {
				CompCode: compCode
			}).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4PurchOrg");
					if (data.results && data.results.length === 1) {
						that.setFieldValue("SearchFormSupplier", "PurchOrg", data.results[0].ekorg);
					} else {
						//Check for default
						for (var i = 0; i < data.results.length; i++) {
							if (data.results[i].Default === true) {
								that.setFieldValue("SearchFormSupplier", "PurchOrg", data.results[i].ekorg);
								break;
							}
						}
					}

					that.checkFieldsStep2();
				});
		},

		loadStep2: function () {

			var that = this;

			//Clear step2
			this.clearStep2Form();

			//CompanyCode
			if (!this.getModel("F4CompCode")) {
				this.callFunction("GetCompCodeList", {}).then(
					function (data) {
						that.setModel(models.createModel(data.results), "F4CompCode");
						if (data.results && data.results.length === 1) {
							that.setFieldValue("SearchFormSupplier", "CompCode", data.results[0].CompCodeKey);
							that._setCompCodeDefaultsInternal(data.results[0]);
							that.loadPurchacingOrg(data.results[0].CompCodeKey);
						} else {
							//Check for default
							for (var i = 0; i < data.results.length; i++) {
								if (data.results[i].Default === true) {
									that.setFieldValue("SearchFormSupplier", "CompCode", data.results[i].CompCodeKey);
									that._setCompCodeDefaultsInternal(data.results[i]);
									that.loadPurchacingOrg(data.results[i].CompCodeKey);
									break;
								}
							}
						}

					});
			}

			that.checkFieldsStep2();
			//this._wizard.nextStep();
			this.getModel("AppControl").setProperty("/visibleStep", 2);
			this.checkFieldsStep2();
		},

		initGoogle: function () {
			//suggestions api & translator api
			if (!window.google) {
				//Add the header - to keep component selfcontained
				var s = document.createElement("script");
				s.type = "text/javascript";
				s.src = "https://maps.googleapis.com/maps/api/js?key=" + this._googleKey + "&libraries=places&language=gb";
				$("head").append(s);
			}
		},

		validEmail: function (email) {
			var pattern =
				/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			//OLD PATTERN: /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
			return pattern.test(email);
		},

		clearStep1Form: function () {

			this.setFieldValue("SearchFormSupplier", "Name1", ""); //check
			this.setFieldValue("SearchFormSupplier", "Searchterm", ""); //check
			this.setFieldValue("SearchFormSupplier", "PostCode1", ""); //check
			this.setFieldValue("SearchFormSupplier", "Country", ""); //check
			this.setFieldValue("SearchFormSupplier", "PostBox", ""); //check
			this.setFieldValue("SearchFormSupplier", "PostCode2", "");
			this.setFieldValue("SearchFormSupplier", "Street", ""); //check
			this.setFieldValue("SearchFormSupplier", "City1", ""); //check
			this.setFieldValue("SearchFormSupplier", "City2", ""); //check
			this.setFieldValue("SearchFormSupplier", "Region", ""); //check
			this.setFieldValue("SearchFormSupplier", "Name2", ""); //check
			this.setFieldValue("SearchFormSupplier", "HouseNum", ""); //check
			this.setFieldValue("SearchFormSupplier", "Region", ""); //check

		},

		clearStep2Form: function () {
			if (this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/BusinessPartner/value") === "") {
				this.setFieldValue("SearchFormSupplier", "VatRegNo", ""); //Clear vatreg
				this.setFieldValue("SearchFormSupplier", "TaxNo1", ""); //Clear Tax Number 1
				this.setFieldValue("SearchFormSupplier", "TaxNo2", ""); //Clear Tax Number 2
			}
			if (this.getModel("SupplierList")) {
				this.getModel("SupplierList").setData([]);
			}

		},

		ClearCustStep2Fields: function () {
			var oEmptyValue = "";
			this.setFieldValue("SearchFormCustomer", "CompCode", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "AccountGroup", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TelNo", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "FaxNo", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "Email", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "VatRegNo", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TaxNo1", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TaxNo2", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TaxNo3", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TaxNo4", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "SalesOrg", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "DistChannel", "01");
			this.setFieldValue("SearchFormCustomer", "Division", "01");
			//this.setFieldValue("SearchFormCustomer", "Langu", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TimeZone", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "TransportZone", oEmptyValue);
			this.setFieldValue("SearchFormCustomer", "FileName1", oEmptyValue);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo1/valueState", sap.ui.core.ValueState.None);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo2/valueState", sap.ui.core.ValueState.None);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo3/valueState", sap.ui.core.ValueState.None);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo4/valueState", sap.ui.core.ValueState.None);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState.None);
			this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", true);
		},

		bindGooglePlace: function (place) {
			var that = this;
			this.clearStep1Form();
			that.getModel("ApplicationFields").setProperty("/formEditable", true);
			if (place.name) {
				var name = place.name;
				//Set the name
				this.setFieldValue("SearchFormSupplier", "Name1", name);
				//Set the search term
				var searchTem = name.split(" ")[0];
				this.setFieldValue("SearchFormSupplier", "Searchterm", searchTem.substring(0, 19));

				var nameLength = name.length;

				if (nameLength > 40) {
					sap.m.MessageBox.information(this.getTools().getText("HelpText-Name_Overflow"), {
						styleClass: "sapUiSizeCompact",
						icon: sap.m.MessageBox.Icon.INFORMATION,
						title: this.getTools().getText("Title-InfoMessage")
					});
				}
			}
			//Build the address fields
			if (place.address_components && place.address_components.length) {
				this.setFieldValue("SearchFormSupplier", "BusinessPartner", "");
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/vendorno", "");
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/text", "");
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/state", "None");
				this.setFieldValue("SearchFormSupplier", "TelNo", "");
				this.setFieldValue("SearchFormSupplier", "Email", "");
				this.setFieldValue("SearchFormSupplier", "Iban", "");
				this.setFieldValue("SearchFormSupplier", "BankCnt", "");
				this.setFieldValue("SearchFormSupplier", "BankKey", "");
				this.setFieldValue("SearchFormSupplier", "BankAcc", "");
				this.setFieldValue("SearchFormSupplier", "BankContKey", "");
				this.setFieldValue("SearchFormSupplier", "VatRegNo", "");
				this.setFieldValue("SearchFormSupplier", "TaxNo1", "");
				this.setFieldValue("SearchFormSupplier", "TaxNo2", "");
				this.setFieldValue("SearchFormSupplier", "TaxNo3", "");
				this.setFieldValue("SearchFormSupplier", "TaxNo4", "");
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/display", false);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/hideother", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/required", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TelNo/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendType/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/enabled", true);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/value", "");
				var addChunks = place.address_components;
				for (var i = 0; i < addChunks.length; i++) {
					var field = null;
					if (addChunks[i].types && addChunks[i].types.length > 0) {
						switch (addChunks[i].types[0]) {
						case "street_number":
							field = "HouseNum";
							break;

						case "route":
							field = "Street";
							break;

						case "locality":
							field = "City1";
							break;

						case "postal_town":
							field = "City1";
							break;

						case "country":
							field = "Country";
							break;

						case "postal_code":
							field = "PostCode1";
							break;

						case "administrative_area_level_1":
							field = "Region";
							if (addChunks[i].short_name && addChunks[i].short_name.length > 3) {
								addChunks[i].short_name = "";
							}
							break;
						}

					}
					//set the address field
					this.setFieldValue("SearchFormSupplier", field, addChunks[i].short_name);

				}
			}

			//Refresh region and validate fields after that 
			this.refreshRegion();
			this.checkFieldsStep1();

			var country = this.getFieldValue("SearchFormSupplier", "Country");
			if (country) {
				this.setCountrySpecifics(country);
			}

			//Set Region to empty value if country is not US
			if (country !== "US") {
				this.setFieldValue("SearchFormSupplier", "Region", "");
			}

		},

		getInco1Data: function (incoKey) {
			var incoList = this.getModel("F4Inco").getData();
			var returnData = null;
			for (var i = 0; i < incoList.length; i++) {
				if (incoList[i].Inco1Key === incoKey) {
					returnData = incoList[i];
					break;
				}
			}

			return returnData;
		},

		getPartnerType: function (accountGrp) {
			var accountGrpList = this.getModel("F4CustAccountGroup").getData();
			var returnData = null;
			for (var i = 0; i < accountGrpList.length; i++) {
				if (accountGrpList[i].AccountGroup === accountGrp) {
					returnData = accountGrpList[i].PartnerType;
					break;
				}
			}
			return returnData;
		},

		setCountrySpecifics: function (country) {
			var that = this;
			var countryData = this.getCountryData(country);
			if (countryData) {

				//Handles country specific required fields
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/StreetI/required", countryData.StreetReq);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Street/required", countryData.StreetReq);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/required", countryData.PostCodeReq);
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/required", countryData.VatRegNo);

				//Start of change JRA 18.06.2020 - Set Vat number required for vendor
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/required", countryData.VatRegNo);
				//End of change JRA 18.06.2020

				//TypeOfBusiness - Get the F4 list and set visibility
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TypeOfBusiness/visible", countryData.TypeOfBusiness);
				if (countryData.TypeOfBusiness === true) {
					this.callFunction("GetTypeBusiness", {
						Country: country
					}).then(
						function (data) {
							that.setModel(models.createModel(data.results), "F4TypeOfBusiness");
						});
				}

				//Attachments signature handling
				this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/AttachmentSignatureRequired", false);
				this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/AttachmentSignatureSigned", false);
				this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/AttachmentSignatureText", "");
				if (countryData.AttachText) {
					this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/AttachmentSignatureRequired", true);
					this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/AttachmentSignatureText", countryData.AttachText);
				}
			}
		},

		getCountryData: function (country) {
			var countryList = this.getModel("F4Countries").getData();
			var returnData = null;
			for (var i = 0; i < countryList.length; i++) {
				if (countryList[i].CountryKey === country) {
					returnData = countryList[i];
					break;
				}
			}

			return returnData;
		},

		getCompCodeData: function (cc) {
			var ccList = this.getModel("F4CompCode").getData();
			var returnData = null;
			for (var i = 0; i < ccList.length; i++) {
				if (ccList[i].CompCodeKey === cc) {
					returnData = ccList[i];
					break;
				}
			}

			return returnData;
		},

		refreshRegion: function () {
			var that = this;
			var country = this.getFieldValue("SearchFormSupplier", "Country");
			var countryData = this.getCountryData(country);

			//Region Required?
			if (countryData) {
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Region/required", countryData.RegionReq);
			}

			if (country) {
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Region/value", "");
				this.callFunction("GetRegionList", {
					Country: country
				}).then(
					function (data) {
						that.setModel(models.createModel(data.results), "F4Regions");
					});
			}
		},

		callFunction: function (functionName, parameters) {
			var that = this;
			return new Promise(function (resolve, reject) {
				//Call the start trace function
				that.getModel().callFunction("/" + functionName, {
					urlParameters: parameters,
					success: resolve,
					error: reject
				});
			});

		},

		getFieldValue: function (block, field) {
			return this.getModel("ApplicationFields").getProperty("/Sections/" + block + "/" + field + "/value");
		},

		setFieldValue: function (block, field, value) {
			this.getModel("ApplicationFields").setProperty("/Sections/" + block + "/" + field + "/value", value);
		},

		setWizard: function (wizard) {
			/*if (!this._wizard) {
				this._wizard = wizard;
			}*/
		},

		handleAttachment: function (filedata, add) {
			var attachments = this.getModel("ApplicationFields").getProperty("/Sections/ControlFields/Attachments");

			if (add) {
				if (attachments.length >= this.getModel("AppControl").getProperty("/MaxUploads")) {
					this.getTools().showMessage("Message-MaxNoAttachments", "warning");
				} else {
					filedata.fileindex = (attachments.length + 1);
					attachments.push(filedata);
				}
			} else {
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/FileName1/name", false);
				for (var i = 0; i < attachments.length; i++) {
					if (attachments[i].filename === filedata.filename) {
						attachments.splice(i, 1);
						break;
					}
				}
			}

			this.getModel("ApplicationFields").setProperty("/Sections/ControlFields/Attachments", attachments);

		},

		uploadAttachment: function (uploaderEvent) {
			if (uploaderEvent.getParameter("files") && uploaderEvent.getParameter("files").length === 1) {
				var that = this;
				var file = uploaderEvent.getParameter("files")[0];
				this.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/FileName1/name", true);
				this._readFile(file).then(function (filedata) {
					that.handleAttachment(filedata, true);
				});
			}
		},

		getFileExtension: function (filename) {
			var ext = /^.+\.([^.]+)$/.exec(filename);
			return ext == null ? "" : ext[1];
		},

		getFileName: function (filename) {
			return (filename.length > 45) ? (filename.substring(0, 45) + "." + this.getFileExtension(filename)) : filename;
		},

		_readFile: function (file) {

			var newFile;
			var reader = new FileReader();

			return new Promise(function (resolve, reject) {
				reader.onload = function (evn) {
					var data = null;
					if (!evn) {
						if (reader.result) {
							data = reader.result;
						} else {
							if (reader.content) {
								data = reader.content;
							}
						}
					} else {
						data = evn.target.result;

						if (!/safari/i.test(navigator.userAgent)) {
							var bytes = new Uint8Array(data);
							var length = bytes.byteLength;
							var binary = "";
							for (var i = 0; i < length; i++) {
								binary += String.fromCharCode(bytes[i]);
							}

							data = binary;
						}
					}

					var ft = file.type;
					var fn = file.name;
					newFile = {
						filename: fn, //file.name,
						fileobj: data,
						filetype: ft
					};

					resolve(newFile);

				};

				if (FileReader.prototype.readAsBinaryString === undefined) {
					reader.readAsArrayBuffer(file);
				} else {
					reader.readAsBinaryString(file);
				}
			});

		},
		wizardCustomerNextStep: function () {
			this.loadCustomerStep2();
		},

		wizardNextStep: function () {
			var that = this;
			//var progress = this._wizard.getProgress();
			var step = this.getModel("AppControl").getProperty("/visibleStep");

			this.handleFooterButtons(step);
			this.showAllFooterButtons(false);

			switch (step) {
			case 1: //Step 1->2
				this.loadStep2();
				break;

			case 2:
				this.loadStep3();
				break;

			case 3:
				this.loadStep4();
				break;

			case 4:
				this.setStep4Specifics();

				// start of insert by EDM 31/05/2018
				var bankRequired = this.isBankRequired();

				if (bankRequired) {
					// end of insert by EDM 31/05/2018

					this.checkBankSAP().then(function () {
						that.loadStep5(); //Load step 5 when form was validated ok in step 4
					}).catch(function (Error) {
						//Bank Check went bad - show a message
						var sMessage = "Bank key is invalid or does not exist in SAP";
						var disMsg = JSON.parse(Error.responseText).error.message.value;
						if (sMessage === disMsg){
							that.getTools().showMessage("Message-BankKeyInvalid", "error");
						}else{
							that.getTools().showMessage(disMsg, "error");
						}
						
						//that.getTools().showMessage("Message-BankKeyInvalid", "error");
						return; //No next step in this case
					});

					// start of insert by EDM 31/05/2018
				} else {
					that.loadStep5(); //Load step 5 when form was validated ok in step 4	
				}
				// end of insert by EDM 31/05/2018

				break;

			}
		},

		wizardPrevStep: function () {
			//this._wizard.previousStep();
			var currentStep = this.getModel("AppControl").getProperty("/visibleStep");
			this.getModel("AppControl").setProperty("/visibleStep", (currentStep - 1));

			if (currentStep === 1) {
				this.getView().getModel("ViewProperties").setProperty("/CustomerWorkflow", false);
				this.getView().getModel("ViewProperties").setProperty("/SupplierWorkflow", false);
			}
			this.handleFooterButtons((currentStep - 1));
		},

		handleFooterButtons: function (step) {
			this.showAllFooterButtons(false);

			switch (step) {
			case 1:
				this.setFooterButtonProps("SupplierStep", {
					enabled: true,
					visible: true
				});
				this.setFooterButtonProps("CustomerStep", {
					enabled: true,
					visible: true
				});
				this.setFooterButtonProps("PrevStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("CustomerPrevStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("SubmitCustomer", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("CancelCustomer", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: false
				});
				this.checkFieldsStep1();
				break;

			case 2:
				this.setFooterButtonProps("SupplierStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("CustomerStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("PrevStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: false
				});

				this.checkFieldsStep2();
				break;

			case 3:
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: true
				});
				this.setFooterButtonProps("PrevStep", {
					enabled: true,
					visible: true
				});

				this.checkFieldsStep3();
				break;

			case 4:
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: true
				});
				this.setFooterButtonProps("PrevStep", {
					enabled: true,
					visible: true
				});

				this.checkFieldsStep4();
				break;

			case 5:
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("PrevStep", {
					enabled: true,
					visible: true
				});

				this.checkFieldsStep5();
				break;

			case 6:
				this.setFooterButtonProps("SupplierStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("CustomerStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("NextStep", {
					enabled: false,
					visible: false
				});
				this.setFooterButtonProps("PrevStep", {
					enabled: true,
					visible: true
				});

				this.checkFieldsStep5();
				break;
			}
		},

		setView: function (viewComp) {
			this._currentView = viewComp;
		},

		searchSuppliers: function () {
			var that = this;
			var fieldStore = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier");

			var params = {
				City: fieldStore.City1.value,
				CompCode: fieldStore.CompCode.value,
				Country: fieldStore.Country.value,
				District: fieldStore.City2.value,
				HouseNum: fieldStore.HouseNum.value,
				Name1: fieldStore.Name1.value,
				Name2: fieldStore.Name2.value,
				PurchOrg: fieldStore.PurchOrg.value,
				Street: fieldStore.Street.value,
				TaxNo1: fieldStore.TaxNo1.value,
				TaxNo2: fieldStore.TaxNo2.value,
				VatRegNo: fieldStore.VatRegNo.value,
				ZIP: fieldStore.PostCode1.value,
				VendorCode: fieldStore.BusinessPartner.vendorno.toString()
			};

			return this.callFunction("GetVendorList", params).then(
				function (data) {

					var compCodeSelected = that.getFieldValue("SearchFormSupplier", "CompCode");
					for (var i = 0; i < data.results.length; i++) {
						if (data.results[i].CompCode === compCodeSelected) {
							data.results[i].Selectable = false;
						} else {
							data.results[i].Selectable = true;
						}

					}

					that.setModel(models.createModel(data.results), "SupplierList");

					//Show supplier buttons
					that.showHideSupplierButtons(true);
				});

		},
		searchCustomers: function () {
			var that = this;
			that.enableCustSubmitButton();
			var Step1fieldStore = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier");
			var Step2fieldStore = this.getModel("ApplicationFields").getProperty("/Sections/SearchFormCustomer");

			var params = {
				City: Step1fieldStore.City1.value,
				Country: Step1fieldStore.Country.value,
				HouseNum: Step1fieldStore.HouseNum.value,
				Name1: Step1fieldStore.Name1.value,
				Name2: Step1fieldStore.Name2.value,
				ZIP: Step1fieldStore.PostCode1.value,
				Street: Step1fieldStore.Street.value,
				Region: Step1fieldStore.Region.value
			};
			var params2 = {
				CompCode: Step2fieldStore.CompCode.value,
				District: Step2fieldStore.City2.value,
				SalesOrg: Step2fieldStore.SalesOrg.value,
				TaxNo1: Step2fieldStore.TaxNo1.value,
				TaxNo2: Step2fieldStore.TaxNo2.value,
				TaxNo3: Step2fieldStore.TaxNo3.value,
				TaxNo4: Step2fieldStore.TaxNo4.value,
				VatRegNo: Step2fieldStore.VatRegNo.value,
				TelNo: Step2fieldStore.TelNo.value,
				FaxNo: Step2fieldStore.FaxNo.value,
				Email: Step2fieldStore.Email.value

			};

			Object.assign(params, params2);

			return this.callFunction("GetCustomerList", params).then(
				function (data) {

					var compCodeSelected = that.getFieldValue("SearchFormCustomer", "CompCode");
					for (var i = 0; i < data.results.length; i++) {
						if (data.results[i].CompCode === compCodeSelected) {
							data.results[i].Selectable = false;
						} else {
							data.results[i].Selectable = true;
						}
					}
					that.setModel(models.createModel(data.results), "CustomerList");
				});

		},

		hideBusyIndicator: function () {
			sap.ui.core.BusyIndicator.hide();
		},
		setViewProperties: function () {
			var oViewProperties = {
				CustomerWorkflow: false,
				SupplierWorkflow: false,
				Name2plus1Field: false

			};
			this.getModel("ViewProperties").setData(oViewProperties);
		},

		showBusyIndicator: function (iDuration, iDelay) {
			sap.ui.core.BusyIndicator.show(iDelay);

			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					jQuery.sap.clearDelayedCall(this._sTimeoutId);
					this._sTimeoutId = null;
				}

				this._sTimeoutId = jQuery.sap.delayedCall(iDuration, this, function () {
					this.hideBusyIndicator();
				});
			}
		},

		getVendorDetails: function (oVendor) {
			var that = this;
			var params = {
				BusinessPartner: oVendor
			};
			this.callFunction("GetBusinessPartner", params).then(
				function (data) {
					that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/busy", false);
					if (data.results.length !== 0) {
						that.setFieldValue("SearchFormSupplier", "VendorNo", data.results[0].VendorNo);
						that.setFieldText("SearchFormSupplier", "BusinessPartner", data.results[0].BusinessPartnerText);
						that.setFieldValue("SearchFormSupplier", "BusinessPartner", data.results[0].BusinessPartnerNo);
						that.setFieldValue("SearchFormSupplier", "TelNo", data.results[0].Telephone);
						that.setFieldValue("SearchFormSupplier", "Email", data.results[0].Email);
						that.setFieldValue("SearchFormSupplier", "Iban", data.results[0].IBAN);
						that.setFieldValue("SearchFormSupplier", "BankCnt", data.results[0].BankCountry);
						that.setFieldValue("SearchFormSupplier", "BankKey", data.results[0].BankKey);
						that.setFieldValue("SearchFormSupplier", "BankAcc", data.results[0].BankAccount);
						that.setFieldValue("SearchFormSupplier", "BankContKey", data.results[0].BankControlKey);
						that.setFieldValue("SearchFormSupplier", "VatRegNo", data.results[0].VatNumber);
						that.setFieldValue("SearchFormSupplier", "TaxNo1", data.results[0].TaxNumber1);
						that.setFieldValue("SearchFormSupplier", "TaxNo2", data.results[0].TaxNumber2);
						that.setFieldValue("SearchFormSupplier", "TaxNo3", data.results[0].TaxNumber3);
						that.setFieldValue("SearchFormSupplier", "TaxNo4", data.results[0].TaxNumber4);
						that.setFieldValue("SearchFormSupplier", "VendType", data.results[0].VendorType);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/vendorno", data.results[0].VendorNo);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/value", "");
					}
				}).catch(function () {
				//Error in BP
				that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/busy", false);
				that.getTools().showMessage("Message-BP", "error");
				return; //No next step in this case
			});
		},

		getBusinessPartnerList: function (oBusinessPartnerValue) {
			var that = this;
			var params = {
				BusinessPartner: oBusinessPartnerValue
			};
			that.callFunction("GetBusinessPartner", params).then(
				function (data) {
					that.setModel(models.createModel(data.results), "F4BusinessPartner");
					that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/busy", false);
					if (data.results.length !== 0) {
						that.clearStep1Form();
						that.setFieldText("SearchFormSupplier", "BusinessPartner", data.results[0].BusinessPartnerText);
						that.setFieldValue("SearchFormSupplier", "BusinessPartner", data.results[0].BusinessPartnerNo);
						that.setFieldValue("SearchFormSupplier", "TelNo", data.results[0].Telephone);
						that.setFieldValue("SearchFormSupplier", "Email", data.results[0].Email);
						that.setFieldValue("SearchFormSupplier", "Country", data.results[0].Country);
						that.setFieldValue("SearchFormSupplier", "Iban", data.results[0].IBAN);
						that.setFieldValue("SearchFormSupplier", "BankCnt", data.results[0].BankCountry);
						that.setFieldValue("SearchFormSupplier", "BankKey", data.results[0].BankKey);
						that.setFieldValue("SearchFormSupplier", "BankAcc", data.results[0].BankAccount);
						that.setFieldValue("SearchFormSupplier", "BankContKey", data.results[0].BankControlKey);
						that.setFieldValue("SearchFormSupplier", "VatRegNo", data.results[0].VatNumber);
						that.setFieldValue("SearchFormSupplier", "TaxNo1", data.results[0].TaxNumber1);
						that.setFieldValue("SearchFormSupplier", "TaxNo2", data.results[0].TaxNumber2);
						that.setFieldValue("SearchFormSupplier", "TaxNo3", data.results[0].TaxNumber3);
						that.setFieldValue("SearchFormSupplier", "TaxNo4", data.results[0].TaxNumber4);
						that.setFieldValue("SearchFormSupplier", "VendType", data.results[0].VendorType);
						that.setFieldState("SearchFormSupplier", "BusinessPartner", "Success");
						that.getModel("ApplicationFields").setProperty("/formEditable", false);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/vendorno", data.results[0].VendorNo);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/required", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/required", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendType/enabled", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/enabled", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/enabled", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/enabled", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/enabled", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/enabled", true);
						that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/value", "");
						that.setFooterButtonProps("SupplierStep", {
							enabled: true,
							visible: true
						});
						that.setFooterButtonProps("CustomerStep", {
							enabled: false,
							visible: true
						});
					} else {
						that.setFieldState("SearchFormSupplier", "BusinessPartner", "Error");
					}
				}).catch(function () {
				//Error in BP
				that.setFieldState("SearchFormSupplier", "BusinessPartner", "Error");
				that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/busy", false);
				that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/display", false);
				that.getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/hideother", true);
				that.getTools().showMessage("Message-BP", "error");
				that.setFooterButtonProps("SupplierStep", {
					enabled: false,
					visible: true
				});
				that.setFooterButtonProps("CustomerStep", {
					enabled: false,
					visible: true
				});
				return; //No next step in this case
			});
		},

		validateWorkFlow: function (Vendor, PurchOrg, CompCode) {
			var params = {
				BusinessPartner: Vendor,
				PurchOrg: PurchOrg,
				CompCode: CompCode
			};
			return this.callFunction("ValidateWorkFlow", params);
		},

		setFieldText: function (block, field, text) {
			this.getModel("ApplicationFields").setProperty("/Sections/" + block + "/" + field + "/text", text);
		},

		setFieldState: function (block, field, state) {
			this.getModel("ApplicationFields").setProperty("/Sections/" + block + "/" + field + "/state", state);
		}

	});
});