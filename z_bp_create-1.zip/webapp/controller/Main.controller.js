sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"grundfos/Z_BP_CREATE/controls/GoogleMap",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/Element"
], function (Controller, UIComponent, GoogleMap, MessageBox, MessageToast, Element) {
	"use strict";

	return Controller.extend("grundfos.Z_BP_CREATE.controller.Main", {
		onInit: function () {
			this.getOwnerComponent().setView(this);
			this.getOwnerComponent().setWizard(this.byId("mainWizard"));
		},
		showHelp: function (oEvent) {
			var that = this; 

			if (oEvent.getSource().data().helptext) {
				if (!this._oPopover) {
					this._oPopover = sap.ui.xmlfragment("grundfos.Z_BP_CREATE.view.popups.InfoMessage", this);

					this.getView().addDependent(this._oPopover);
				}

				var text = this.getOwnerComponent().getTools().getText(oEvent.getSource().data().helptext);

				this._oPopover.attachAfterOpen(null, function () {
					sap.ui.getCore().byId("infoText").setText(text);
				}, null);
				this._oPopover.attachAfterClose(null, function () {
					sap.ui.getCore().byId("infoText").setText("");
				}, null);
				this._oPopover.openBy(oEvent.getSource());
			} else {
				throw "Missing i18n help text config";
			}

		},

		onActivateStep: function (oEvent) {
			var step = oEvent.getSource().data().step;
			this.getOwnerComponent().getModel("AppControl").setProperty("/visibleStep", parseInt(step));
			this.getOwnerComponent().handleFooterButtons(parseInt(step));
			//this.getOwnerComponent().wizardNextStep();
			if (step <= 1) {
				this.getView().getModel("ViewProperties").setProperty("/CustomerWorkflow", false);
				this.getView().getModel("ViewProperties").setProperty("/SupplierWorkflow", false);
			}

		},

		StepButtonType: function (step) {

		},

		onChangeInco1: function (oEvent) {
			//Get the default texts if avail
			var selectedKey = oEvent.getSource().getSelectedKey();
			var dataPack = this.getOwnerComponent().getInco1Data(selectedKey);

			this.getOwnerComponent().setFieldValue("SearchFormSupplier", "Inco2", ((dataPack.Inco2Default) ? dataPack.Inco2Default : ""));

			this.onCheckFieldsStep5(oEvent);
		},
		onSetIbanMode: function (oEvent) {
			this.getOwnerComponent().refreshBankvisibility(true);
			this.getOwnerComponent().checkFieldsStep4();
		},
		onChangePayMethod: function (oEvent) {
			this.getOwnerComponent().refreshBankvisibility();
			this.onCheckFieldsStep4(oEvent);
		},
		onChangeCompCode: function (oEvent) {
			if (this.getOwnerComponent().getModel("SupplierList")) {
				this.getOwnerComponent().getModel("SupplierList").setData([]);
			}

			this.getOwnerComponent().setCompCodeDefaults(oEvent);
			this.getOwnerComponent().loadPurchacingOrg(oEvent.getSource().getSelectedKey());
			this.onCheckFieldsStep2(oEvent);
		},
		onChangeCustCompCode: function (oEvent) {
			if (this.getOwnerComponent().getModel("SearchFormCustomer")) {
				this.getOwnerComponent().getModel("SearchFormCustomer").setData([]);
			}
			this.getOwnerComponent().checkCompCodeValue(oEvent);
			this.getOwnerComponent().setCustCompCodeDefaults(oEvent);
			this.getOwnerComponent().loadSalesOrg(oEvent.getSource().getSelectedKey());
			this.getOwnerComponent().loadCustTimeZone(oEvent.getSource().getSelectedKey());
			this.getOwnerComponent().loadCustTransportZone(oEvent.getSource().getSelectedKey());
			this.getOwnerComponent().updateSalesGroup("");
		  
			this.onCheckCustFieldsStep2(oEvent);
			this.CheckCompFieldValue();
			
		    this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/enabled", false);
			this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/enabled", false);
			
		},
		CheckCompFieldValue: function () {

		},
		onSupplierSearch: function () {
			var that = this;

			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TelNo/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/required", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TelNo/required", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankCnt/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankKey/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankAcc/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BankContKey/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendType/value", "");
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendType/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Ibanmode/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco1/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco2/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PaymtMethod/enabled", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco1/required", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/required", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PaymtMethod/required", true);
			that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendorNo/value", "");
			var BPDisplay = that.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/BusinessPartner/display");
			if (BPDisplay === false) {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/vendorno", "");
			}

			this.getOwnerComponent().searchSuppliers().then(function () {
				var oBusinessPartnerValue = that.getView().getModel("ApplicationFields").getProperty(
					"/Sections/SearchFormSupplier/BusinessPartner/display");

				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/value", false);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/click", false);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PurchOrgCB/value", false);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/CompCodeCB/value", false);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/enabled", true);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TelNo/enabled", true);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/AddNewBankInfo/visible", false);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Ibanmode/mode", "");
				if (oBusinessPartnerValue === true) {

					var timed = function () {
						$(that.byId("supplierTable2").getDomRef()).height(0);
					};
					window.setTimeout(timed, 1000);
				} else {
					var timed = function () {
						$(that.byId("supplierTable2").getDomRef()).height(0);
					};
					window.setTimeout(timed, 1000);
				}
			});
		},
		onCustomerSearch: function () {
			var that = this;
			this.getOwnerComponent().searchCustomers().then(function () {
				var timed = function () {
					$(that.byId("customerTable").getDomRef()).height(0);
				};
				window.setTimeout(timed, 1000);

			});
			this.getOwnerComponent().enableCustSubmitButton(true);

		},

		onAddField: function () {
			this.getView().getModel("ViewProperties").setProperty("/Name2plus1Field", true);

		},

		onRemoveField: function () {
			this.getView().getModel("ViewProperties").setProperty("/Name2plus1Field", false);
		},

		onNextStep: function () {
			this.getOwnerComponent().wizardNextStep();
		},

		onNextStepExtend: function () {
			var that = this;
			var oSupplierNeedExtensionValue = that.getView().getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/SupplierNeedExtension/click");
			var oVendorNo = this.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/VendorNo/value");

			if (oSupplierNeedExtensionValue === false) {
				MessageBox.error(that.getOwnerComponent().getTools().getText("Message-BP_Extend"));
				return;
			} else {

				var PurchOrgCB = this.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/PurchOrgCB/value");
				var CompCodeCB = this.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/CompCodeCB/value");
				if (PurchOrgCB) {
					var PurchOrg = this.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/PurchOrg/value");
				} else {
					PurchOrg = "";
				}
				if (CompCodeCB) {
					var CompCode = this.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/CompCode/value");
				} else {
					CompCode = "";
				}

				//Check if Workflow already Exists
				this.getOwnerComponent().validateWorkFlow(oVendorNo, PurchOrg, CompCode).then(function (data) {
					if (data.ValidateWorkFlow.WFExist) {
						MessageBox.error(that.getOwnerComponent().getTools().getText("Message-WFExists"));
					} else {
						that.getOwnerComponent().getVendorDetails(oVendorNo);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/value", true);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/AddNewBankInfo/visible", true);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Email/required", false);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TelNo/required", false);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Iban/required", false);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendType/enabled", false);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/enabled", true);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/enabled", true);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/enabled", true);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/enabled", true);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/enabled", false);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/required", false);
						that.getView().getModel("ApplicationFields").setProperty("/Sections/ControlFields/IbanMode/enabled", false);
						
						if ((!PurchOrgCB) && (CompCodeCB)) {
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco1/required", false);
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco2/required", false);
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/required", false);
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Currency/enabled", false);
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco1/enabled", false);
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/Inco2/enabled", false);
						}
						if ((PurchOrgCB) && (!CompCodeCB)) {
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PaymtMethod/required", false);
							that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PaymtMethod/enabled", false);
						}

						that.getOwnerComponent().wizardNextStep();
					}
				}).catch(function () {
					//Error
				});

			}
		},

		onCustomerPrevStep: function () {
			this.getOwnerComponent().onCustomerPrevStep();

		},

		onCreateSupplierStep: function () {

			this.getOwnerComponent().wizardNextStep();
			this.getView().getModel("ViewProperties").setProperty("/SupplierWorkflow", true);
		},

		onCreateCustomerStep: function () {
			this.getOwnerComponent().wizardCustomerNextStep();
			this.getView().getModel("ViewProperties").setProperty("/CustomerWorkflow", true);
		},

		onPrevStep: function () {
			this.getOwnerComponent().wizardPrevStep();
			this.enableGoogleSearchOnInput("googleSearch");

		},
		onCheckFieldsStep1: function () {
			this.getOwnerComponent().checkFieldsStep1();
		},
		onCheckFieldsStep2: function () {
			this.getOwnerComponent().checkFieldsStep2();
		},
		onCheckCustFieldsStep2: function () {
			this.getOwnerComponent().checkCustFieldsStep2();
		},
		onChangePostCode1: function () {
			this.onCheckFieldsStep1();
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueState", sap.ui.core.ValueState
					.Error);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueStateTxt");

			};

			return this.getOwnerComponent().validatePostCode1().then(function (data) {
				//that.getOwnerComponent().setField
				if (data.ValidatePostCode.ErrorText !== "") {
					that.errorOccured(data);
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueState", sap.ui.core.ValueState
						.Success);
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueStateTxt", that.getOwnerComponent()
						.getTools().getText("Message-VatRegValid"));
				}
				that.onCheckFieldsStep1();
			}).catch(function () {
				errorOccured();
				that.onCheckFieldsStep1();
			});
		},

		errorOccured: function (data) {
			this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueState", sap.ui.core.ValueState
				.Error);
			this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueStateTxt");
			MessageBox.error(data.ValidatePostCode.ErrorText);

		},

		onChangeSalesOrg: function (oEvent) {
			var that = this;
			var salesOrg = oEvent.getSource().getSelectedKey();
			this.getOwnerComponent().checkCustFieldsStep2();
			this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", true);
			this.getOwnerComponent().updateAccountGroup(salesOrg);
			this.getOwnerComponent().updateSalesOffice(salesOrg);
			this.getOwnerComponent().updateSalesGroup("");
			//this.getView().byId("SalesGroup").setValue(" ");
			return this.getOwnerComponent().checkSOSGenable2(salesOrg).then(function (data) {
				if ( data.ValidateSoffSgrpEnable.Result ) {
				  that.getOwnerComponent().reLoadSalesOffice();
			     // that.getOwnerComponent().reLoadSalesGroup();	
			      that.getOwnerComponent().updateSalesGroup("");
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/enabled", true);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/enabled", true);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/required", true);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/required", true);
			      //that.getOwnerComponent().checkCustFieldsStep2();
				} else {
			      that.getOwnerComponent().updateSalesOffice("");
				  that.getOwnerComponent().updateSalesGroup("");	
				  that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/enabled", false);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/enabled", false);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/required", false);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/required", false);
			      //that.getOwnerComponent().checkCustFieldsStep2();
				}
			}).catch(function () {
			}); 
		},
		onChangeSalesOffice: function (oEvent) {
			var salesOffice = oEvent.getSource().getSelectedKey();
		//	this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", true);
		//	this.getOwnerComponent().updateAccountGroup(salesOrg);
	    	this.getOwnerComponent().updateSalesGroup("");
			this.getOwnerComponent().updateSalesGroup(salesOffice);
			this.getOwnerComponent().checkCustFieldsStep2();
		},
		
		onChangeSalesGroup: function (oEvent) {
			var salesGroup = oEvent.getSource().getSelectedKey();
			this.getOwnerComponent().checkCustFieldsStep2();
		//	this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", true);
		//	this.getOwnerComponent().updateAccountGroup(salesOrg);
		//	this.getOwnerComponent().updateSalesGroup(salesOffice);
		},
		

		onChangeAccountGroup: function (oEvent) {
			var that = this;
			var accountgrp = oEvent.getSource().getSelectedKey();
			var partnerType = this.getOwnerComponent().getPartnerType(accountgrp);
            //var salesorg = this.getView().byId("SalesOrg").getValue();

			// If it is a payer or bill_to then transportation zone is not required
			if (partnerType === "2" || partnerType === "3") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", false);
			} else {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TransportZone/required", true);
			}

			// If it is bill_to then time zone is not required
			if (partnerType === "3") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TimeZone/required", false);
			} else {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TimeZone/required", true);
			}
			
		//	this.getOwnerComponent().checkCustFieldsStep2();
		//	var SOSG_FLAG = this.getOwnerComponent().checkSOSGenable(salesorg,accountgrp);
			return this.getOwnerComponent().checkSOSGenable1(accountgrp).then(function (data) {
				if ( data.ValidateSoffSgrpEnable.Result ) {
			      that.getOwnerComponent().reLoadSalesOffice();
			      //that.getOwnerComponent().reLoadSalesGroup();
			      that.getOwnerComponent().updateSalesGroup("");
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/enabled", true);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/enabled", true);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/required", true);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/required", true);
			      that.getOwnerComponent().checkCustFieldsStep2();
				} else {
				  that.getOwnerComponent().updateSalesOffice("");
				  that.getOwnerComponent().updateSalesGroup("");
				  that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/enabled", false);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/enabled", false);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesOffice/required", false);
			      that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/SalesGroup/required", false);
			      that.getOwnerComponent().checkCustFieldsStep2();
				}
			}).catch(function () {
			});
			
		},

		onCheckFieldsStep3: function () {
			this.getOwnerComponent().checkFieldsStep3();
		},
		onCheckFieldsStep4: function () {
			this.getOwnerComponent().checkFieldsStep4();
		},
		onCheckFieldsStep5: function () {
			this.getOwnerComponent().checkFieldsStep5();
		},
		onChangeCountry: function (oEvent) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueState", sap.ui.core.ValueState
					.Error);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueStateTxt");

			};

			this.getOwnerComponent().refreshRegion();
			this.getOwnerComponent().setCountrySpecifics(oEvent.getSource().getSelectedKey());
			this.getOwnerComponent().validatePostCode1().then(function (data) {
				//that.getOwnerComponent().setField
				if (data.ValidatePostCode.ErrorText !== "") {
					that.errorOccured(data);
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueState", sap.ui.core.ValueState
						.Success);
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PostCode1/valueStateTxt", that.getOwnerComponent()
						.getTools().getText("Message-VatRegValid"));
				}
				that.onCheckFieldsStep1();
			}).catch(function () {
				errorOccured();
				that.onCheckFieldsStep1();
			});
			this.onCheckFieldsStep1();
		},
		onDeleteAttachment: function (oEvent) {
			var filedata = oEvent.getSource().getBindingContext("ApplicationFields").getObject();
			this.getOwnerComponent().handleAttachment(filedata, false);
			this.onCheckFieldsStep4(oEvent);
		},
		onCustDeleteAttachment: function (oEvent) {
			var filedata = oEvent.getSource().getBindingContext("ApplicationFields").getObject();
			this.getOwnerComponent().handleAttachment(filedata, false);
		},
		onHandleUploadComplete: function (oEvent) {
			this.getOwnerComponent().uploadAttachment(oEvent);
			this.getOwnerComponent().checkFieldsStep5();
		},
		onHandleUploadComplete4: function (oEvent) {
			this.getOwnerComponent().uploadAttachment(oEvent);
			this.onCheckFieldsStep4(oEvent);
		},

		onHandleCustUploadComplete: function (oEvent) {
			this.getOwnerComponent().uploadAttachment(oEvent);
		},

		onCheckIban: function (oEvent) {
			var that = this;
			var iban = oEvent.getSource().getValue();

			this.byId("inputIban").setValueState(sap.ui.core.ValueState.None);
			this.byId("inputIban").setValueStateText("");
			if (this.getOwnerComponent().isEmpty(iban) === false) {
				//Validate the iban in SAp and online
				//this.getOwnerComponent().checkIBANSAP(iban).catch(function(){

				var invalidIban = function () {
					that.byId("inputIban").setValueState(sap.ui.core.ValueState.Error);
					that.byId("inputIban").setValueStateText(that.getOwnerComponent().getTools().getText("Message-IbanInvalid"));
				};

				//Call online service if sap fails - just in case
				that.getOwnerComponent().checkIBANSAP(iban).then(function (data) {

					if (data.ValidateIBAN.BankCnt) {
						that.byId("inputIban").setValueState(sap.ui.core.ValueState.Success);
						that.getOwnerComponent().setBankDataFromIban(data.ValidateIBAN);
						that.getOwnerComponent().checkFieldsStep4();

						//Fire Country Change
						that.getOwnerComponent()._checkBankFieldsInternal();
					} else {
						invalidIban();
					}

					//that.byId("inputIban").setValueStateText("I LOVE IT");
				}).catch(function (data) {
					invalidIban();
				});
				//});
			}

			//Check all fields
			this.getOwnerComponent().checkFieldsStep4();
		},
		onCheckBankCountry: function (oEvent) {
			//Check visibility on Iban etc
			this.getOwnerComponent().checkBankFields(oEvent);

			//Check fields in step
			this.getOwnerComponent().checkFieldsStep4();

		},
		showMap: function (place) {
			var map = new GoogleMap({
				key: "AIzaSyADA2M_23Ms41hsW9Rv_r1EUoOnCu9gPZE",
				center: place.geometry.location
			});

			this.byId("mapBox").insertItem(map);
		},
		onSupplierFoundOutside: function (oevent) {
			this.getOwnerComponent().getTools().showMessage("Message-FeatureNotClarified", "success");
		},
		onSupplierFound: function (oevent) {
			this.getOwnerComponent().getTools().showMessage("Message-SupplierExistsPleaseCarryOn", "success");
		},

		onSubmitOK: function () {
			var that = this;
			this.getOwnerComponent().submitSupplier().then(function () {

				MessageBox.confirm(
					that.getOwnerComponent().getTools().getText("Message-CreatedSuccessfully"), {
						actions: [sap.m.MessageBox.Action.OK],
						onClose: function () {
							that.byId("mainWizard").setVisible(false);
							that.byId("butSubmit").setVisible(false);
							that.byId("stepHeader").setVisible(false);
							window.top.location.reload();
						}
					});

				//Reload the page to reset 

			}).catch(function (error) {
				var title = that.getOwnerComponent().getTools().getText("");
				that.getOwnerComponent().showMessagesFromError(error, title);
			});
		},

		onCustSubmitOK: function () {
			var that = this;
			that.getOwnerComponent().submitCustomer();
			/*.then(function () {
				

						}).catch(function (error) {
							var title = that.getOwnerComponent().getTools().getText("Submit Data Failed");
							that.getOwnerComponent().showMessagesFromError(error, title);
						});*/
		},

		onCheckVatRegNoStep5: function (oEvent) {
			var vatReg = oEvent.getSource().getValue();
			var that = this;
			if (vatReg) {
				this._validateVatReg(vatReg).then(function () {
					that.onCheckFieldsStep5(oEvent);
				});
			} else {
				this.onCheckFieldsStep5(oEvent);
			}
		},

		_validateVatReg: function () {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueState", sap.ui.core.ValueState
					.Error);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueStateTxt", that.getOwnerComponent()
					.getTools().getText("Message-VatRegInvalid"));
				that.getOwnerComponent()._vatRegValid = false;
			};

			return this.getOwnerComponent().checkVatRegInSAP().then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateVatRegNo.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueState", sap.ui.core.ValueState
						.Success);
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueStateTxt", that.getOwnerComponent()
						.getTools().getText("Message-VatRegValid"));

					that.getOwnerComponent()._vatRegValid = true;
				}
			}).catch(function () {
				errorOccured();
			});
		},

		onCheckVatRegNo: function (oEvent) {
			var vatReg = oEvent.getSource().getValue();
			if (vatReg) {
				this._validateVatReg(vatReg);

			}

		},

		onCheckCustVatRegNoLiveChange: function (oEvent) {
			var that = this;
			var enabled = false;
			var vatRegNoField = oEvent.getSource().getValue();
			if (vatRegNoField === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
					.None);
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/value", vatRegNoField);
			}
			this._validateCustVatReg();
			this.getOwnerComponent().checkCustFieldsStep2();
			this.getView().getModel("UIControl").setProperty("/CustomerSearch/enabled", enabled);
		},

		_validateCustVatReg: function () {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
					.Error);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueStateTxt", that.getOwnerComponent()
					.getTools().getText("Message-VatRegInvalid"));
				that.getOwnerComponent()._vatRegValid = false;
				that.getOwnerComponent().checkCustFieldsStep2();
			};

			return this.getOwnerComponent().checkCustVatRegInSAP().then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateVatRegNo.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
						.Success);
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueStateTxt", that.getOwnerComponent()
						.getTools().getText("Message-VatRegValid"));

					that.getOwnerComponent()._vatRegValid = true;
					that.getOwnerComponent().checkCustFieldsStep2();
				}
			}).catch(function () {
				errorOccured();
			});
		},

		onValidateVatNoPress: function () {
			var vatReg = this.getView().byId("custVatRegNo").getValue();
			var that = this;
			sap.ui.core.BusyIndicator.show();
			if (vatReg === "") {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
					.None);
			} else {
				if (vatReg) {
					that._validateCustVatReg(vatReg);
				}
			}
			sap.ui.core.BusyIndicator.hide();
			that.getOwnerComponent().checkCustFieldsStep2();
		},

		/*	onCheckCustVatRegNo: function (oEvent) {
				var vatReg = oEvent.getSource().getValue();
				if (vatReg === "") {
					this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
						.None);
					//	this.getOwnerComponent()._vatRegValid = true;
				} else {
					if (vatReg) {
						this._validateCustVatReg(vatReg);
					}
				}
				this.getOwnerComponent().checkCustFieldsStep2();
			},*/
		/*	onCheckCustVatRegNoOnButtonPress: function (oEvent) {
				var vatReg = this.getView().byId("custVatRegNo").getValue();
				if (vatReg === "") {
					this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/valueState", sap.ui.core.ValueState
						.None);
					//	this.getOwnerComponent()._vatRegValid = true;
				} else {
					if (vatReg) {
						this._validateCustVatReg(vatReg);
					}
				}
				this.getOwnerComponent().checkCustFieldsStep2();
			},*/
		oncustVatRegNoCheckBox: function (oEvent) {
			var that = this;
			var oCheckBoxValue = oEvent.getParameters().selected;
			if (oCheckBoxValue === true) {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/required", false);
				this.getOwnerComponent()._vatRegValid = true;

			} else {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/VatRegNo/required", true);
				this.getOwnerComponent()._vatRegValid = false;
			}
			this.getOwnerComponent().checkCustFieldsStep2();

		},

		onSubmit: function () {
			var that = this;
			MessageBox.confirm(
				this.getOwnerComponent().getTools().getText("Message-SureUWantToSubmit"), {
					actions: [sap.m.MessageBox.Action.CANCEL, sap.m.MessageBox.Action.OK],
					onClose: function (sAction) {
						switch (sAction) {
						case sap.m.MessageBox.Action.OK:
							that.onSubmitOK();
							break;

						case sap.m.MessageBox.Action.CANCEL:
							//Do nothing
							break;

						default:
							break;
						}
					}
				}
			);

		},

		onCustSubmit: function () {
			var that = this;
			MessageBox.confirm(
				this.getOwnerComponent().getTools().getText("Message-SureUWantToSubmitCust"), {
					actions: [sap.m.MessageBox.Action.CANCEL, sap.m.MessageBox.Action.OK],
					onClose: function (sAction) {
						switch (sAction) {
						case sap.m.MessageBox.Action.OK:
							that.onCustSubmitOK();
							break;

						case sap.m.MessageBox.Action.CANCEL:
							//Do nothing
							break;

						default:
							break;
						}
					}
				}
			);

		},

		onEmailChange: function (oEvent) {
			var selected = oEvent.getSource().getSelected();

			if (!selected) {
				this.getOwnerComponent().setFieldValue("SearchFormSupplier", "Email_Fin", "");
			}
		},
		onCancelCustomer: function (oEvent) {
			var step = "1";
			this.getOwnerComponent().getModel("AppControl").setProperty("/visibleStep", parseInt(step));
			this.getOwnerComponent().handleFooterButtons(parseInt(step));
			if (step <= 1) {
				this.getView().getModel("ViewProperties").setProperty("/CustomerWorkflow", false);
				this.getView().getModel("ViewProperties").setProperty("/SupplierWorkflow", false);
			}
		},

		onNoVATChange: function (oEvent) {
			var required = true;
			var that = this;
			var selected = oEvent.getSource().getSelected();

			if (selected) {
				this.getOwnerComponent().setFieldValue("SearchFormSupplier", "VatRegNo", "");
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueState", sap.ui.core.ValueState
					.Success);
				//	that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueState", null );
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/valueStateTxt", null);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/visible", false);

				that.getView().getModel("ApplicationFields").getProperty("/Sections/SearchFormSupplier/VatRegNo/required", required);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/required", false);

				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/enabled", false);

				this.onCheckFieldsStep5(oEvent);
			} else {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/required", required);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VatRegNo/enabled", true);
				this.onCheckFieldsStep5(oEvent);
			}
		},

		checkWebsite: function (place) {
			var visible = false;
			if (place.website) {
				visible = true;
			}

			this.byId("websitelnk").setVisible(visible);
			this.byId("websitelnk-link").setHref(place.website);
		},

		checkCompanyLogo: function (place) {
			var visible = false;
			if (place.icon) {
				visible = true;
			}

			this.byId("companyImage").setVisible(visible);
			this.byId("companyImage").setSrc(place.icon);
		},

		onSearchSelected: function (place) {
			//Handle website
			this.checkWebsite(place.getParameters());
			//Bind data to fields
			this.getOwnerComponent().bindGooglePlace(place.getParameters());
		},

		onChangeTelNo: function (oEvent) {
			this.onCheckFieldsStep3(oEvent);
		},

		onEmailCheck: function (oEvent) {
			var input = oEvent.getSource();
			input.setValueState(sap.ui.core.ValueState.None);
			input.setValueStateText("");

			if (!this._invalidEmailText) {
				this._invalidEmailText = this.getOwnerComponent().getTools().getText("Message-InvalidEmail");
			}

			if (this.getOwnerComponent().validEmail(input.getValue()) === false) {
				input.setValueState(sap.ui.core.ValueState.Error);
				input.setValueStateText(this._invalidEmailText);
				this.getOwnerComponent().setFooterButtonProps("NextStep", {
					enabled: false,
					visible: true
				});
			} else {
				input.setValueState(sap.ui.core.ValueState.Success);
				var timedAction = function () {
					input.setValueState(sap.ui.core.ValueState.None);
				};
				window.setTimeout(timedAction, 1000);
				this.onCheckFieldsStep3(oEvent);
			}
		},

		onCustEmailCheck: function (oEvent) {
			var input = oEvent.getSource();
			input.setValueState(sap.ui.core.ValueState.None);
			input.setValueStateText("");

			if (!this._invalidEmailText) {
				this._invalidEmailText = this.getOwnerComponent().getTools().getText("Message-InvalidEmail");
			}

			if (this.getOwnerComponent().validEmail(input.getValue()) === false) {
				input.setValueState(sap.ui.core.ValueState.Error);
				input.setValueStateText(this._invalidEmailText);

			} else {
				input.setValueState(sap.ui.core.ValueState.Success);
				var timedAction = function () {
					input.setValueState(sap.ui.core.ValueState.None);
				};
				window.setTimeout(timedAction, 1000);

			}
		},

		onCheckSearchField: function (oEvent) {
			if (!oEvent.getSource().getValue()) {
				this.getOwnerComponent().clearStep1Form();
			}
		},
		onAfterRendering: function () {

		},
		onSelectCompCode: function (oEvent) {
			var that = this;
			var cxt = oEvent.getSource().getBindingContext("SupplierList");
			var obj = cxt.getObject();
			if (obj.SupplierAccountGroup === "ZG") {
				obj.CompCodeCB = false;
				MessageBox.error("Group vendor can’t be extended here!");
			} else {
				if (oEvent.getSource().getSelected()) {
					obj.CompCodeCB = true;
					if (!obj.PurchOrg) {
						obj.PurchOrgCB = true;
					}
				} else {
					obj.CompCodeCB = false;
				}
				var i;
				var entrySelected = 0;
				for (i = 0; i < cxt.oModel.oData.length; i++) {
					if (cxt.oModel.oData[i].PurchOrgCB === true || cxt.oModel.oData[i].CompCodeCB === true) {
						entrySelected++;
					}
					if (entrySelected > 1) {

						obj.PurchOrgCB = false;
						obj.CompCodeCB = false;
						MessageBox.error("Extend One Supplier");
						entrySelected = 1;
						break;
					}
				}

				if (entrySelected === 1) {
					this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/click", true);
					var CBset = false;
					for (i = 0; i < cxt.oModel.oData.length; i++) {
						if (cxt.oModel.oData[i].CompCodeCB === true) {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/CompCodeCB/value", true);
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendorNo/value", cxt.oModel.oData[i].VendorNo);
							CBset = true;
						} else {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/CompCodeCB/value", false);

						}
						if (cxt.oModel.oData[i].PurchOrgCB === true) {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendorNo/value", cxt.oModel.oData[i].VendorNo);
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PurchOrgCB/value", true);
							CBset = true;
						} else {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PurchOrgCB/value", false);
						}
						if (CBset) {
							break;
						}
					}
				} else {
					this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/click", false);
				}
			}
		},
		onSelectPurchOrg: function (oEvent) {
			var that = this;
			var cxt = oEvent.getSource().getBindingContext("SupplierList");
			var obj = cxt.getObject();
			if (obj.SupplierAccountGroup === "ZG") {
				obj.PurchOrgCB = false;
				MessageBox.error("Group vendor can’t be extended here!");
			} else {
				if (oEvent.getSource().getSelected()) {
					obj.PurchOrgCB = true;
					if (!obj.CompCode) {
						obj.CompCodeCB = true;
					}
				} else {
					obj.PurchOrgCB = false;
				}

				var i;
				var entrySelected = 0;
				for (i = 0; i < cxt.oModel.oData.length; i++) {
					if (cxt.oModel.oData[i].PurchOrgCB === true || cxt.oModel.oData[i].CompCodeCB === true) {
						entrySelected++;
					}
					if (entrySelected > 1) {

						obj.PurchOrgCB = false;
						obj.CompCodeCB = false;
						MessageBox.error("Extend One Supplier");
						entrySelected = 1;
						break;
					}
				}

				if (entrySelected === 1) {
					this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/click", true);
					var CBset = false;
					for (i = 0; i < cxt.oModel.oData.length; i++) {
						if (cxt.oModel.oData[i].CompCodeCB === true) {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/CompCodeCB/value", true);
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendorNo/value", cxt.oModel.oData[i].VendorNo);
							CBset = true;
						} else {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/CompCodeCB/value", false);
						}
						if (cxt.oModel.oData[i].PurchOrgCB === true) {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PurchOrgCB/value", true);
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/VendorNo/value", cxt.oModel.oData[i].VendorNo);
							CBset = true;
						} else {
							this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/PurchOrgCB/value", false);
						}
						if (CBset) {
							break;
						}
					}
				} else {
					this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/SupplierNeedExtension/click", false);
				}
			}
		},

		onSelectAddBankInfo: function (oEvent) {

			if (oEvent.getSource().getSelected()) {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/FileName1/required", true);
			} else {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/FileName1/required", false);
			}
			this.onCheckFieldsStep4(oEvent);
		},
		formatterCompCodeIconColor: function (compCode) {
			var compCodeSelected = this.getOwnerComponent().getFieldValue("SearchFormSupplier", "CompCode");
			if (!compCodeSelected || compCode !== compCodeSelected) {
				return "red";
			} else {
				return "green";
			}
		},
		formatterCompCodeIcon: function (compCode) {
			var compCodeSelected = this.getOwnerComponent().getFieldValue("SearchFormSupplier", "CompCode");
			if (!compCodeSelected || compCode !== compCodeSelected) {
				return "sap-icon://sys-cancel";
			} else {
				return "sap-icon://accept";
			}
		},
		formatterPurchOrgIconColor: function (purchOrg) {
			var purchOrgSelected = this.getOwnerComponent().getFieldValue("SearchFormSupplier", "PurchOrg");
			if (!purchOrgSelected || purchOrg !== purchOrgSelected) {
				return "red";
			} else {
				return "green";
			}
		},
		formatterPurchOrgIcon: function (purchOrg) {
			var purchOrgSelected = this.getOwnerComponent().getFieldValue("SearchFormSupplier", "PurchOrg");
			if (!purchOrgSelected || purchOrg !== purchOrgSelected) {
				return "sap-icon://sys-cancel";
			} else {
				return "sap-icon://accept";
			}
		},
		formatterStripZeros: function (value) {
			if (value !== "") {
				value = (!value) ? "" : value.trim();
				return "" + parseInt(value, 10);
			} else {
				return "";
			}
		},
		onOpenExternalHelp: function () {
			this.getOwnerComponent().openExternalHelp();
		},
		onChangeTaxNo1: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo1/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateTaxNo1(taxNo);
				}
			}

		},
		onChangeTaxNo2: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo2/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateTaxNo2(taxNo);
				}
			}
		},

		onChangeTaxNo3: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo3/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateTaxNo3(taxNo);
				}
			}
		},

		onChangeTaxNo4: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo4/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateTaxNo4(taxNo);
				}
			}
		},
		_validateTaxNo1: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo1/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkCustTaxNoInSAP("TaxNo1").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo1/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},

		_validateTaxNo2: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo2/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkCustTaxNoInSAP("TaxNo2").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo2/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},
		_validateTaxNo3: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo3/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkCustTaxNoInSAP("TaxNo3").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo3/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},
		_validateTaxNo4: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo4/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkCustTaxNoInSAP("TaxNo4").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormCustomer/TaxNo4/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},
		onSupplierChangeTaxNo1: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateSupplierTaxNo1(taxNo);
				}
			}

		},
		onSupplierChangeTaxNo2: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateSupplierTaxNo2(taxNo);
				}
			}
		},

		onSupplierChangeTaxNo3: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateSupplierTaxNo3(taxNo);
				}
			}
		},

		onSupplierChangeTaxNo4: function (oEvent) {
			var taxNo = oEvent.getSource().getValue();
			if (taxNo === "") {
				this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/valueState", sap.ui.core.ValueState
					.None);
				//	this.getOwnerComponent()._vatRegValid = true;
			} else {
				if (taxNo) {
					this._validateSupplierTaxNo4(taxNo);
				}
			}
		},
		_validateSupplierTaxNo1: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkSupplierTaxNoInSAP("TaxNo1").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo1/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},

		_validateSupplierTaxNo2: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkSupplierTaxNoInSAP("TaxNo2").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo2/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},
		_validateSupplierTaxNo3: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkSupplierTaxNoInSAP("TaxNo3").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo3/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},
		_validateSupplierTaxNo4: function (taxNo) {
			var that = this;
			var errorOccured = function () {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/valueState", sap.ui.core.ValueState
					.Error);
				//	that.getOwnerComponent()._taxNo1Valid = false;
			};

			return this.getOwnerComponent().checkSupplierTaxNoInSAP("TaxNo4").then(function (data) {
				//that.getOwnerComponent().setField
				if (!data.ValidateTaxNum.Result) {
					errorOccured();
				} else {
					//All is good paint it green
					that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/TaxNo4/valueState", sap.ui.core.ValueState
						.Success);
				}
				//		that.getOwnerComponent()._taxNo1Valid = true;
			}).catch(function () {
				errorOccured();
			});
		},
		onCheckBusinessPartner: function () {
			var that = this;
			this.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/busy", true);
			this.getOwnerComponent().setFieldText("SearchFormSupplier", "BusinessPartner", "");
			var oBusinessPartnerValue = this.getView().getModel("ApplicationFields").getProperty(
				"/Sections/SearchFormSupplier/BusinessPartner/value");

			this.getOwnerComponent().getBusinessPartnerList(oBusinessPartnerValue);

			if (oBusinessPartnerValue === "") {
				that.getView().getModel("ApplicationFields").setProperty("/formEditable", true);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/text", "");
				that.getOwnerComponent().setFooterButtonProps("SupplierStep", {
					enabled: false,
					visible: true
				});
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/display", false);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/hideother", true);
			} else {
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/display", true);
				that.getView().getModel("ApplicationFields").setProperty("/Sections/SearchFormSupplier/BusinessPartner/hideother", false);
			}
		}
	});
});

jQuery.sap.declare("zgrundfos.custom.formatter");

zgrundfos.custom.formatter = {

	formatterColor: function (status) {
		if (status === "Blocked" || status === "Deleted") {
			this.addStyleClass("red");
		}
		return status;
	},

	formatterVisbilityCompCodeIcon: function (status, compcode) {
		if (status === "Blocked" || status === "Deleted") {
			return true;
		} else {
			if (compcode) {
				return true;
			} else {
				this.addStyleClass("hideCB");
				return false;
			}
		}

	},
	formatterVisbilityPurchOrgIcon: function (status, purchorg) {
		if (status === "Blocked" || status === "Deleted") {
			return true;
		} else {
			if (purchorg) {
				return true;
			} else {
				this.addStyleClass("hideCB");
				return false;
			}
		}

	},
	formatterVisbilityCompCodeCB: function (status, compcode) {

		if (status === "Blocked" || status === "Deleted") {
			this.addStyleClass("hideCB");
			return true;
		} else {
			if (compcode) {
				this.addStyleClass("hideCB");
				return true;
			} else {
				return true;
			}
		}
	},

	formatterVisbilityPurchOrgCB: function (status, purchorg) {

		if (status === "Blocked" || status === "Deleted") {
			this.addStyleClass("hideCB");
			return true;
		} else {
			if (purchorg) {
				this.addStyleClass("hideCB");
				return true;
			} else {
				return true;
			}
		}
	}
};