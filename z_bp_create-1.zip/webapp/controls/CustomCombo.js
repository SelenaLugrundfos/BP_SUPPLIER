sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Control"
], function(jQuery, Control) {
	"use strict";
	
	//*****************************************************************************
	//Allan Christensen Gavdi Labs A/S 03.2018
	//Custom Control developed for overcoming the limitation with SAPUI5 Comboboxes
	//That allow entering data not in the suggestionlists.
	//Based on the JQuery plugin Select2. https://select2.org/
	//*****************************************************************************

	var CustomCombo = Control.extend("grundfos.Z_BP_CREATE.controls.CustomCombo", {
		
		metadata: {
			properties:
			{
				width:				{ type:  "string", defaultValue:"250px" },
				minWidth:			{ type:  "string", defaultValue:"100%" },
				selectedKey:		{ type:  "string" },
				enabled:			{ type:  "boolean", defaultValue: true },
				tabIndex:			{ type:  "int", defaultValue: -1 }
			},
			events:
			{
				change: {}
			},
			aggregations: {
				items: {
					type: "sap.ui.core.Item"
				}
			},
			defaultAggregation: "items"
		},

		init: function() {
			
		
		},

		renderer:
		{
			render: function(oRm, oControl)
			{
				oRm.write("<select tabindex=\"" + oControl.getTabIndex() + "\" class=\"js-example-basic-single\" style=\"width:" + oControl.getWidth() +";min-width:" + oControl.getMinWidth() + "\" name=\"state\"");
				oRm.writeControlData(oControl);
				oRm.writeClasses();
				oRm.write(">");
				oRm.write("<option value=\"\"></option>"); //blank
				$(oControl.getItems()).each(function() {
					oRm.write("<option value=\"" + this.getKey() + "\"");
					if( oControl.getSelectedKey() )
					{
						if( oControl.getSelectedKey() === this.getKey() )
						{
							oRm.write( " selected " );
						}
					}
					oRm.write(">");
					oRm.write(this.getText());
					oRm.write("</option>");
				});
				oRm.write("</select>");
			}
		}
	});
	
	CustomCombo.prototype.onAfterRendering = function()
	{
		var that = this;
		
		//Enabled?
		var disabled = !this.getEnabled();
		$("#"+this.getId()).prop('disabled', disabled);
		
		/*Call the JS library*/
		$(document).ready(function() {
		    $('.js-example-basic-single').select2({
		    	width: that.getWidth()
		    });
		});
		
		//Register the select2 event for selection an option in the dropdown
		$("#"+this.getId()).on("select2:select", function (e) {
			var data = e.params.data;
    		that.setSelectedKey( data.id );
    		that.fireChange();
		});
	};

	return CustomCombo;

});