sap.ui.define(
    ['sap/m/Input'],
    function(Input) {
        return Input.extend("grundfos.Z_BP_CREATE.controls.CustomInput",{
            metadata: {
                properties: {
                    tabIndex: {
                        type: "int",
                        defaultValue: -1
                    }
                },
                events : {
            		"change" : {}
        		}
            },
            renderer: function(oRm,oControl){
                sap.m.InputRenderer.render(oRm,oControl); //use supercass renderer routine
            },
            onAfterRendering: function()
	        {
	        	var that = this;
	        	$( "#" + this.getId() + " > div > input" ).attr("tabIndex",this.getTabIndex());
	        	//$(this.getDomRef());//.tabIndex = this.getTabIndex();
	        	
	        	$( "#" + this.getId() + " > div > input" ).change(function() {
				  that.fireChange();
				});
	        }
        });
    }
);