sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Control"
], function(jQuery, Control) {
	"use strict";

	var GoogleAutoComplete = Control.extend("grundfos.Z_BP_CREATE.controls.GoogleAutoComplete", {
		metadata: {
			properties:
			{
				key:				{ type:  "string" },
				value:				{ type:  "string", defaultValue: "" },
				width:				{ type:  "string" },
				tabIndex:			{ type:  "int", defaultValue: -1 }
			},
			events:
			{
				searchSelected:			{},
				clear:					{}
			}
		},

		init: function() {
			
		
		},

		renderer:
		{
			render: function(oRm, oControl)
			{
				oRm.write("<div style=\"width:" + oControl.getWidth() + "\" ");
				oRm.writeControlData(oControl);
				oRm.writeClasses();
				oRm.write(">");
					oRm.write("<div>");
						oRm.write("<input tabindex=\"" + oControl.getTabIndex() + "\" placeholder=\"Enter search criteria\" value=\"" + oControl.getValue() + "\" >");
					oRm.write("</div>");
				oRm.write("</div>");
			}
		}
	});

	GoogleAutoComplete.prototype.onAfterRendering = function()
	{
		var that = this;
		var domref = this.getDomRef();
		var timedAction = function()
			{
				if( domref && google )
				{
					var input	= domref.childNodes[0].childNodes[0];
					
				    var autocomplete = new google.maps.places.Autocomplete(input);
				      google.maps.event.addListener(autocomplete, 'place_changed', function(){
				      	
				         var place = autocomplete.getPlace();
				         that.fireSearchSelected(place);
				         
				         that.setValue(place.name);
				      });
				}
				
			};
			window.setTimeout(timedAction,1000);
	};

	return GoogleAutoComplete;

});