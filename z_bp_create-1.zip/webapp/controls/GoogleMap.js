sap.ui.define([
	"jquery.sap.global",
	"sap/ui/core/Control"
], function(jQuery, Control) {
	"use strict";

	var GoogleMap = Control.extend("grundfos.Z_BP_CREATE.controls.GoogleMap", {
		metadata: {
			properties:
			{
				key:				{ type:  "string" },
				center: 			{ type:  "object" },
				circleRadiusInKM:	{ type:  "int" },
				zoom:				{ type:  "int", defaultValue: 10 }
			}
		},

		init: function() {
			
		
		},

		renderer:
		{
			render: function(oRm, oControl)
			{
				window.document.controller = oControl;
				oRm.write("<div style=\"height:100%;width:100%\"");
				oRm.writeControlData(oControl);
				oRm.writeClasses();
				oRm.write(">");
				oRm.write("</div>");
			}
		}
	});
	
	GoogleMap.prototype.getCenterLocation = function()
	{
		return this.center;	
	};
	
	GoogleMap.prototype.addMarker = function( markerCenter, icon, infoWindowContent )
	{
		var marker = new window.google.maps.Marker({
			position: markerCenter,
			map: this.map
		});
		
		if( icon )
		{
			marker.setIcon( icon );
/*			icon: icon,
			originalpin: icon*/
		}
		
		if( infoWindowContent  )
		{
			var infowindow = new window.google.maps.InfoWindow({
				content: infoWindowContent
			});

			marker.addListener('click', function()
			{
				infowindow.open(marker.get('map'), marker);
			});
		}
		
		marker.setMap(this.map);
	};
	
	GoogleMap.prototype.createCircle = function( )
	{
			//circle			
			this.storeCircle = new window.google.maps.Circle
			({
				strokeColor: '#002C5F',
				strokeOpacity: 0.8,
				strokeWeight: 2,
				fillColor: '#00b9e4',
				fillOpacity: 0.35,
				map: this.map,
				center: this.center,
				radius: (this.getCircleRadiusInKM() * 1000) //km to meters
			});
	};
	
	GoogleMap.prototype._initMap = function()
	{
			//this.origin = new google.maps.LatLng(data.originLat, data.originLng);
			
			//Update the origin
			var that = this;
			this.center = new window.google.maps.LatLng(this.getCenter().lat, this.getCenter().lng);
	
			//Options for the map
			this.mapOptions = {
				center: this.center,
				zoom: this.getZoom(),
				draggable: true,
				mapTypeId: window.google.maps.MapTypeId.ROADMAP
			};
			this.map = new window.google.maps.Map(this.getDomRef(), this.mapOptions);
		
			//Circle?
			if( this.getCircleRadiusInKM() )
			{
				this.createCircle();
			}
			
			//Needed to update the map after creation
			window.google.maps.event.addListenerOnce(that.map, 'idle', function()
			{
				window.google.maps.event.trigger(that.map, 'resize');
				//Pan to center
				var timed = function()
				{
					that.map.panTo(this.center);
					that.map.setCenter(this.center);
				};
				window.setTimeout(timed,1500);
			});
			
			

	};

	GoogleMap.prototype.onAfterRendering = function()
	{
		this._initMap();
	};

	return GoogleMap;

});